<?php


class Functions
{
    public function __construct($array=[])
    {
        echo '<pre>';
        print_r($array);
        echo '</pre>';
    }

}