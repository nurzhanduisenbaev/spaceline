<?php
return array(
    'host'       => 'srv-pleskdb16.ps.kz',
    'dbname'     => 'spacelin_space',
    'user'       => 'space_line.kz',
    'password'   => 'Web123!@#',
);