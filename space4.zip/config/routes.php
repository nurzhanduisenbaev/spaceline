<?php

return array(
	// Referal
	'referal/([0-9]+)'  => 'referal/referal/$1',
	// Админская часть
	'admin/queries'     	=> 'admin/queries',
	'admin/taken/([0-9]+)'     	=> 'admin/taken/$1',
	'admin/takes'     	=> 'admin/takes',
	'admin/take'     	=> 'admin/take',
	'admin/profile'     => 'admin/profile',
	'admin/academyadd'     => 'admin/academy',
	'admin/academy'     => 'admin/academy',
	'admin/newsadd'     	=> 'admin/newsadd',
	'admin/news'     	=> 'admin/news',
	'admin/teamsreg'     	=> 'admin/teamsreg',
	'admin/teams'     	=> 'admin/teams',
	'admin/team/page-([0-9]+)'     	=> 'admin/team/$1',
	'admin/logout'    	=> 'admin/logout',
	'admin/cabinet/page-([0-9]+)'     => 'admin/cabinet/$1',
	'admin'     		=> 'admin/login',
	
	'video'     		=> 'video/index',
	'literatura'     	=> 'literatura/index',
	// Академия 
	'academy'     		=> 'academy/index',
	// Новости
	'news/add'     		=> 'news/add',
	'news'     			=> 'news/index',
	// Мой профиль
	'profile/editphoto/([0-9]+)'			=> 'profile/editphoto/$1',
	'profile/edit/([0-9]+)'			=> 'profile/edit/$1',
	'profile/index/([0-9]+)'		=> 'profile/index/$1',
	
	// Пассивный Доход
	'passive'     => 'passive/passive',
    // Мои доходы
	'income/table'      => 'income/table',
    'income/index/page-([0-9]+)'       		=> 'income/index/$1',

    // Моя структура
	'team/lich/([0-9]+)'		=> 'team/lich/$1',
    'team/tree/([0-9]+)'        => 'team/tree/$1',
    'team/index/([0-9]+)'        => 'team/index/$1',

    // Регистрация пользователей
    'user/register'     => 'user/register',

    // Главная страница
	'cabinet/take'      => 'cabinet/take',
    'cabinet/logout'    => 'cabinet/logout',
    'cabinet'           => 'cabinet/index',
    
    // Авторизация пользователей
    'index.php'         => 'login/index', // actionIndex в SiteController
    ''                  => 'login/index', // actionIndex в SiteController
);
