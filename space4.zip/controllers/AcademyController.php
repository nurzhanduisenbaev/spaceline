<?php
class AcademyController{

	public function actionIndex(){
		$userId = User::checkLogged();
		$user 	= User::getUserById($userId);
		



		require_once(ROOT . '/views/academy/index.php');
		return true;
	}
}

?>