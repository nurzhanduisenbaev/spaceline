<?php
class AdminController{
	public function actionLogin(){
		
        // Переменные для формы
        $email = false;
        $password = false;
		
        // Обработка формы
        if (isset($_POST['submit'])) {
            // Если форма отправлена
            // Получаем данные из формы
            $email 		= $_POST['email'];
            $password 	= $_POST['password'];

            // Флаг ошибок
            $errors = false;

            // Валидация полей
            if (!Admin::checkEmail($email)) {
                $errors[] = 'Неправильный email';
            }
            if (!Admin::checkPassword($password)) {
                $errors[] = 'Пароль не должен быть короче 6-ти символов';
            }

            // Проверяем существует ли пользователь
            $userId = Admin::checkUserData($email, $password);
			echo $userId;
            if ($userId == false) {
                // Если данные неправильные - показываем ошибку
                $errors[] = 'Неправильные данные для входа на сайт';
            } else {
                // Если данные правильные, запоминаем пользователя (сессия)
                Admin::auth($userId);

                // Перенаправляем пользователя в закрытую часть - кабинет
                header("Location: /admin/cabinet/page-".$userId);
            }
        }
        require_once(ROOT . '/views/admin/login.php');
        return true;
    }
	public function actionCabinet($page=1){
		$userId = Admin::checkLogged();
        $user 	= Admin::getUserById($userId);
		$treeUser   = User::getTreeById($userId);
		$income    	= Team::incomeAll($page);
		$total	  	= Team::incomeAllCount();
		$totalCount = count($total);
		//print_r($users);
		
		$dayInc = Income::getIncome3();
		$allInc = Admin::takeIncome();
		$partnerCount = Admin::takeCount();
		$account = Admin::takeAccount();
		$liderCount = Admin::takeCountLider();
		$pagination = new Pagination($totalCount, $page, Team::SHOW_BY_DEFAULT, 'page-');
		require_once(ROOT . '/views/admin/cabinet.php');
        return true;
	}
	public function actionLogout(){
        unset($_SESSION['user']);
        header('Location: /admin');    
	}
	public function actionTeam($page=1){
		$userId = Admin::checkLogged();
        $user 		= Admin::getUserById($userId);
		//$users  = User::getUsers();
		$users    	= Team::usersAll($page);
		$total	  	= Team::usersAllCount();
		$totalCount = count($total);
		//print_r($users);
		$pagination = new Pagination($totalCount, $page, Team::SHOW_BY_DEFAULT, 'page-');
		require_once(ROOT . '/views/admin/team.php');
        return true;
	}
	public function actionTeams(){
		$userId = Admin::checkLogged();
        $user 	= Admin::getUserById($userId);
		$db = Db::getConnection();
		
		$sql = "SELECT *FROM user WHERE role='Лидер'";
		$result = $db->query($sql);
		
		
		require_once(ROOT . '/views/admin/teams.php');
        return true;
	}
	public function actionTeamsreg(){
		$userId = Admin::checkLogged();
        $user 	= Admin::getUserById($userId);
		$getProduct = User::getProducts();
		$errors = false;
        $trues  = array();
		$last = User::lastID();
		$last_id = $last['id']+1;
		
        if(isset($_POST['register'])){
            $name           = $_POST['name'];
            $surname        = $_POST['surname'];
            $fathername     = $_POST['lastname'];

            $role           = $_POST['role'];
            $email          = $_POST['email'];
            $password       = $_POST['password'];

            $date_of_born   = $_POST['data_born'];
            $sex            = $_POST['sex'];
            $iin            = $_POST['iin'];
            $card           = $_POST['card'];
            $invoice        = $_POST['invoice'];
            $data_reg       = $_POST['data_reg'];

            $country        = $_POST['country'];
            $city           = $_POST['city'];
            $street         = $_POST['street'];
            $house          = $_POST['house'];
            $room           = $_POST['room'];
            $product        = $_POST['product'];
            $team           = $_POST['team'];
            //$oplata         = $_FILES['oplata'];


            // Валидация полей
            if (!Admin::checkPassword($password)) {
                $errors[]  = 'Пароль не должен быть короче 6-ти символов';
            }
            if (Admin::checkEmailExists($email)) {
                $errors[] = 'Парнер с таким email существет';
            }
            if($errors == false){
                $db = Db::getConnection();
				$sql = "INSERT INTO user(id,name,surname,lastname,role,parent_id,email,password,data_born,sex,iin,card,invoice,data_reg,
				country,city,street,house,room,product,team,access) ";
				$sql .="VALUES ('$last_id','$name','$surname','$fathername','$role','0','$email','$password','$date_of_born','$sex','$iin',
				'$card','$invoice','$data_reg','$country','$city','$street','$house','$room','$product','$team','разрешен')";
				$result = $db->query($sql);
				if($result){
					$sql2    = "INSERT INTO team(name) VALUES('$team')";
					$result2 = $db->query($sql2);
					if($result2){
						header("Location: /admin/teams/".$user['id']);
					}
				}
            }

        }
		
		require_once(ROOT . '/views/admin/teamsreg.php');
        return true;
	}
	public function actionNewsadd(){
		$userId = Admin::checkLogged();
        $user 	= Admin::getUserById($userId);
		if(isset($_POST['add'])){
			$title 		 = $_POST['title'];
			$description = $_POST['description'];
			$date 		 = date("Y-m-d H:i");
			$author      = $user['name'];
			$image       = 'none.jpg';
			$db = Db::getConnection();
			$sql = "INSERT INTO news (author,title,description,date,image) VALUES('$author','$title','$description','$date','$image')";
			$result = $db->query($sql);
			if($result){
				header("Location: /admin/news");
			
			}
		}
		require_once(ROOT . '/views/admin/newsadd.php');
        return true;
	}
	public function actionNews(){
		$userId = Admin::checkLogged();
        $user 	= Admin::getUserById($userId);
		$db = Db::getConnection();
		$sql = "SELECT *FROM news";
		$result = $db->query($sql);
		require_once(ROOT . '/views/admin/news.php');
        return true;
	}
	public function actionAcademy(){
		$userId = Admin::checkLogged();
        $user 	= Admin::getUserById($userId);
		$db = Db::getConnection();
		$sql = "SELECT *FROM academy";
		$result = $db->query($sql);
		require_once(ROOT . '/views/admin/academy.php');
        return true;
	}
	public function actionAcademyadd(){
		$userId = Admin::checkLogged();
        $user 	= Admin::getUserById($userId);
		if(isset($_POST['add'])){
			$title 		 = $_POST['title'];
			$description = $_POST['description'];
			$date 		 = date("Y-m-d H:i");
			$author      = $user['name'];
			$image       = 'none.jpg';
			$db = Db::getConnection();
			$sql = "INSERT INTO news (author,title,description,date,image) VALUES('$author','$title','$description','$date','$image')";
			$result = $db->query($sql);
			if($result){
				header("Location: /admin/academy");
			
			}
		}
		require_once(ROOT . '/views/admin/newsadd.php');
        return true;
	}
	public function actionProfile(){
		$userId = Admin::checkLogged();
        $user 	= Admin::getUserById($userId);
		require_once(ROOT . '/views/admin/profile.php');
        return true;
	}
	public function actionTake(){
		$userId 	= Admin::checkLogged();
        $user 		= Admin::getUserById($userId);
		$result2 	= Admin::takeT();
		//print_r($result2);
		if(isset($_POST['podtverdit'])){
			$user_id 	= $_POST['user_id'];
			
			$email 		= $_POST['email'];
			$fio 		= $_POST['fio'];
			$sum 		= $_POST['sum'];
			$team 		= $_POST['team'];
			$invoice 	= $_POST['invoice'];
			$iin 		= $_POST['iin'];
			$card 		= $_POST['card'];
			$res = Income::viplaty($user_id, $email, $team, $fio, $sum);
			$up  = Income::upTake(2, $email);
			$to = $email;
			//$to = "nurzhanduisenbaev480@mail.ru";
			$subject = "Подтверждение";
			$txt = "Ваша выплата  была одобренна , деньги зачислятся на ваш лицевой счет в течении 3-х банковских дня. Благодарим за сотрудничество с компанией Space Line ";
			$headers = "From: info@spaceline.kz" . "\r\n" .
				"CC: $to";

			$mail = mail($to,$subject,$txt,$headers);
			if($mail){
				//$to = $email;
				$to 		= "buh@spaceline.kz";
				$subject 	= "Подтверждение";
				$txt = "Пользователь : $fio
						Одобрено в выплате!
						Сумма $sum
						ИИН: $iin
						Лицевой счет:$invoice
						Номер карты: $card";
				$headers = "From: info@spaceline.kz" . "\r\n" .
					"CC: $to";

				$mail2 = mail($to,$subject,$txt,$headers);
				header("Location: /admin/take");
			}
		}
		require_once(ROOT . '/views/admin/take.php');
        return true;
	}
	public function actionTakes(){
		$userId 	= Admin::checkLogged();
        $user 		= Admin::getUserById($userId);
		$result2 	= Admin::takeM();
		//print_r($result2);
		
		require_once(ROOT . '/views/admin/takes.php');
        return true;
	}
	public function actionQueries(){
		$userId 	= Admin::checkLogged();
        $user 		= Admin::getUserById($userId);
		$ok 		= false;
		$result2 	= Admin::takeU();
		$db  = Db::getConnection();
		if(isset($_POST['prinyat'])){
			$email 		= $_POST['email'];
			$user_id 	= $_POST['user_id'];
			$id			= $_POST['id'];
			$name		= $_POST['name'];
			$surname    = $_POST['surname'];
			$password   = $_POST['password'];
			
			$team		= $_POST['team'];
			$product    = $_POST['product'];
			$side       = $_POST['side'];
			$group_id   = $_POST['group_id'];
			$sql  = "UPDATE user SET access='разрешен' WHERE `group_id`='$group_id'";
			$sql2 = "UPDATE tree SET access='разрешен' WHERE `group_id`='$group_id'";
			$result3 = $db->query($sql);
			$result4 = $db->query($sql2);
			//$rrr = false;
			if($result3){
				//Bonuses
				$user2     	= User::getUserById($user_id);
				//$user3      = User::getUserById();
				$fio 		= $name.' '.$surname;
				///$up	 		= User::updateTreeSide($user2['email'], $side, $email);
				//if($up){
				$lichnyi 		= Income::selfBonus($user2['id'],$user2['email'],$user2['team'], $product, $name, $surname);
				$lider 			= Income::liderBonusAlgorithm($user_id, $product,$fio);
				$quick 			= Income::quickBonusAlgorithm($user_id);
				//}
				//Bonuses
				//$rrr = true;
				$to = $email;
				$subject = "Подтверждение";
				$txt = "Благодарим вас за регистрацию в партнерской программе Spaceline. 
						Ваш кабинет активирован. 
						Данные для входа: 
						Логин: $email
						Пароль: $password
						Желаем вам Успехов!";
				$headers = "From: info@spaceline.kz" . "\r\n" .
				"CC: $to";

				mail($to,$subject,$txt,$headers);
				//header("Location: /admin/queries");
				$ok = true;
				echo "<script>alert('Пользователь добавлен');</script>";
				header("Location: /admin/queries");
			}else{
				//header("Location: /admin/queries");
				echo "<script>alert('Что-то пошло не так');</script>";
			}
		}
		if(isset($_POST['otklonit'])){
			header("Location: /admin/queries");
			echo "<script>alert('Пользователь отклонен');</script>";
		}
		require_once(ROOT . '/views/admin/queries.php');
        return true;
	}
	
}

?>