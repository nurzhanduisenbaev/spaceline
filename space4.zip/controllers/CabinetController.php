<?php

class CabinetController {
    //put your code here
    public function actionIndex(){
		
		$ok  = false;
		$ok2 = false;
		$_SESSION['ok'] = 'no';
		//setcookie('ok','no');
        $userId = User::checkLogged();
        $user 	= User::getUserById($userId);
		$income  = Income::getIncome3();
		$income2 = Income::getIncome4($user['email']);
		//
		$income3 = Income::getIncome5($user['id']);
		//
		$income4 = Income::getIncome6($user['email']);
		$income5 = Income::getIncome7($user['email']);
		//
		//passive
		$income8 = Income::getIncome8($user['email']);
		$income9 = Income::getIncome9($user['email']);
		//
		$childs  = Team::getChilds($userId);
		$childs2 = Team::getChilds($userId);
		$userCount = Cabinet::getUsers();
		$arr = array();
		while($row10 = $childs->fetch(PDO::FETCH_ASSOC)){
			$arr[] = $row10;
		}
		$us[] = $user;
		$arr = array_merge($us,$arr);
		//echo '<pre>';
		//print_r($arr);
		//echo '</pre>';
		$countArr = count($arr);
		$day    = 0;
		while($row1 = $income->fetch(PDO::FETCH_ASSOC)){
			//echo $row1['id'];
			$day = $day+(($row1['total']*100)/16.07);
		}
		$account    = 0;
		while($row2 = $income2->fetch(PDO::FETCH_ASSOC)){
			//echo $row1['id'];
			$account = $account+$row2['countL'];
		}
		$teampack    = 0;
		$teamer = array();
		while($row3 = $income3->fetch(PDO::FETCH_ASSOC)){
			//echo $row1['id'];
			//$teamer[] = $row3;
			$teampack = $teampack+(($row3['total']*100)/16.07);
		}
		//echo '<pre>';
		//print_r($teamer);
		//echo '</pre>';
		$all    = 0;
		while($row4 = $income4->fetch(PDO::FETCH_ASSOC)){
			//echo $row1['id'];
			$all = $all+$row4['total'];
		}
		$all2    = 0;
		while($row5 = $income5->fetch(PDO::FETCH_ASSOC)){
			//echo $row1['id'];
			$all2 = $all2+$row5['total'];
		}
		$c = array();
		$date1 = date("Y-m-01");
		$date2 = date("Y-m-30");
		while($row7 = $childs2->fetch(PDO::FETCH_ASSOC)){
			if(($row7['data_reg']>=$date1) && ($row7['data_reg']<=$date2)){
				$c[] = $row7;
			}
		}
		
		
        require_once(ROOT . '/views/cabinet/index.php');
        return true;
    }
    public function actionLogout(){
        unset($_SESSION['user']);
        header('Location: /');
    }
	public function actionTake(){
		$userId = User::checkLogged();
        $user 	= User::getUserById($userId);
		global $all;
		$summa 		= $_POST['summa2'];
			
		$name    	= $_POST['tname'];
		$surname 	= $_POST['tsurname'];
		$user_id 	= $_POST['tuser_id'];
		$email 		= $_POST['temail'];
		$invoice 	= $_POST['tinvoice'];
		$iin 		= $_POST['tinn'];
		$card 		= $_POST['tcard'];

		$fio 		= $name.' '.$surname;
		$date 		= date('Y-m-d H:i:s');
		$getm = Cabinet::getMoney($user_id,$email,$fio,$date,$summa,$invoice,$iin,$card);
		if(Cabinet::mailToAdmin($fio,$invoice,$email,$date,$summa)){
			echo 'ok';
			return true;
		}
		
		return false;
    }
}
