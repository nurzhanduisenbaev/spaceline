<?php


class IncomeController
{
	public function __construct($page){
		//print_r($page);
		//$this->actionIndex($page[0]);
	}
	
    public function actionIndex($page=1){
		//echo $page;
		//echo '<br>';
        $userId     = User::checkLogged();
        $user       = User::getUserById($userId);
        $total22      = Income::getTotalIncome();
		/////////////////////////////
        $income     = Income::getIncome2($user['email'],$page);
		$tot 		= Income::getTotalProductsInCategory($user['email']);
		//echo '<pre>';
		//print_r($tot);
		//echo '</pre>';
		//echo $income;
		//die();
		//$totCount = count($tot);
		///////////////////////
		
		
        $treeUser   = User::getTreeById($userId);
		$lc         = array();
		$rc         = array();
		
		$fio = $user['name'].' '.$user['surname'];
		$getIncome = Income::getIncome($user['email'], 'Парный Бонус');
		if(!$getIncome){
			Income::bothBonus($userId,$user['email'],$user['team'], $user['name'], $user['surname']);
		}else{
			$leftEmail      = $treeUser['mleft'];
			$rightEmail     = $treeUser['mright'];

			$lco = 0;
			$rco = 0;
			if($leftEmail != ''){
				$lEmail = User::getTreeByEmail($leftEmail);
				if($lEmail != null){
					$lc = Team::getLeftChilds($lEmail);

					$lco = count($lc);
				}else{
					$lco = 0;
				}
			}else{
				$lco = 0;
			}
			if($rightEmail != ''){
				$rEmail = User::getTreeByEmail($rightEmail);

				if($rEmail != null){
					$rc = Team::getRightChilds($rEmail);
					$rco = count($rc);
				}else{
					$rco = 0;
				}
			}else{
				$rco = 0;
			}
			$childs = Team::takeChild($user['email']);
			if($childs){
				Team::updateChild($lco, $rco, $user['email']);
			}else{
				Team::insertChild($lco, $rco, $user['email']);
			}

		}

		$getIncome2 = Income::getIncome($user['email'], 'Парный Бонус');
		if(!$getIncome2){
			Income::bothBonus($userId,$user['email'],$user['team'], $user['name'], $user['surname']);
		}else{
			$countLIncome       = $getIncome2['countL'];
			$countRIncome       = $getIncome2['countR'];
			$total              = $getIncome2['total'];
			$parnyi             = 0;
			$bilet              = 0;
			$ch                 = Team::takeChild($user['email']);
			$childLeftCount     = $ch['countL'];
			$childRightCount    = $ch['countR'];
			$ostatka            = 0;
			if((($childLeftCount-$countLIncome)!=0) || (($childRightCount-$countRIncome)!=0)){
				if($childLeftCount<$childRightCount){
					$parnyi  = ($childLeftCount-$countLIncome)*7500;
					$ostatka = $childLeftCount;                    
					if($childLeftCount>=5){
						$bilet = (int)($childLeftCount/5);
					}
					if($parnyi != 0){
						Income::bothBonus($userId,$user['email'],$user['team'], $user['name'],
										  $user['surname'], $ostatka,$ostatka,$parnyi);
					}
				}
				else if($childRightCount<$childLeftCount){
					$parnyi = ($childRightCount-$countRIncome)*7500;
					$ostatka = $childRightCount;

					if($childRightCount>=5){
						$bilet = (int)($childRightCount/5);
					}
					if($parnyi != 0){
						Income::bothBonus($userId,$user['email'],$user['team'], $user['name'],
										  $user['surname'], $ostatka,$ostatka,$parnyi);
					}
				}else{

					$parnyi = ($childRightCount-$countRIncome)*7500;
					if($childRightCount>=5){
						$bilet = (int)($childRightCount/5);
					}
					$ostatka = $childRightCount;
					if($parnyi != 0){
						Income::bothBonus($userId,$user['email'],$user['team'], $user['name'],
										  $user['surname'], $ostatka,$ostatka,$parnyi);
					}
				}

				Income::updateBilet($user['email'],$bilet);
			}

		}
		$getIncome3 = Income::getIncome($user['email'], 'Парный Бонус(Минус за Билет)');
		if(!$getIncome3){
			Income::bothBonusForBilet($userId,$user['email'],$user['team'], $user['name'], $user['surname']);
		}else{
			$countLIncome       = $getIncome3['countL'];
			$countRIncome       = $getIncome3['countR'];
			$total              = $getIncome3['total'];
			$parnyi             = 0;

			$ch                 = Team::takeChild($user['email']);
			$childLeftCount     = $ch['countL'];
			$childRightCount    = $ch['countR'];
			$ostatka            = 0;
			if((($childLeftCount-$countLIncome)!=0) || (($childRightCount-$countRIncome)!=0)){
				if($childLeftCount<$childRightCount){						                    
					if($childLeftCount>=5){
						$parnyi  	= ((int)(($childLeftCount-$countLIncome)/5))*7500;
						$ostatka 	= $childLeftCount - ($childLeftCount%5);

					}
					if($parnyi != 0){
						Income::bothBonusForBilet($userId,$user['email'],$user['team'], $user['name'],
												  $user['surname'], $ostatka,$ostatka,$parnyi);
					}
				}
				else if($childRightCount<$childLeftCount){
					if($childRightCount>=5){
						$parnyi 	= ((int)(($childRightCount-$countRIncome)/5))*7500;
						$ostatka 	= $childRightCount - ($childRightCount%5);

					}
					if($parnyi != 0){
						Income::bothBonusForBilet($userId,$user['email'],$user['team'], $user['name'],
												  $user['surname'], $ostatka,$ostatka,$parnyi);
					}
				}else{
					if($childRightCount>=5){
						$ostatka 	= $childRightCount - ($childRightCount%5);
						$parnyi 	= ((int)(($childRightCount-$countRIncome)/5))*7500;							
					}else{
						$parnyi = 0;
					}						
					if($parnyi != 0){
						Income::bothBonusForBilet($userId,$user['email'],$user['team'], $user['name'],
												  $user['surname'], $ostatka,$ostatka,$parnyi);
					}
				}
			}

		}
		// Office Bonuses

		if(($user['bilet'] >= 5) && ($user['mstatus'] == 'Партнер')){
			Income::updateStatus($user['email'],'Директор');
			Income::updateStatusTree($user['email'],'Директор');
			Income::premiaBonus($user['id'], $user['email'], $user['team'], $fio, 130000, 'Премия за Директора');
		}
		if((count($lc)!=0) && count($rc)!=0){
			$lDirector = Team::checkLeftStatus($lc, 'Директор');
			$rDirector = Team::checkRightStatus($rc, 'Директор');
			if(($lDirector == true) && ($rDirector == true) && ($user['mstatus'] == 'Директор')){
				Income::updateStatus($user['email'],'Золотой директор');
				Income::updateStatusTree($user['email'],'Золотой директор');
				Income::premiaBonus($user['id'], $user['email'], $user['team'], $fio, 300000, 'Премия за Золотой директор');
			}
		}

		if((count($lc)!=0) && count($rc)!=0){
			$lDirector2 = Team::checkLeftStatus($lc, 'Золотой директор');
			$rDirector2 = Team::checkRightStatus($rc, 'Золотой директор');
			if(($lDirector2 == true) && ($rDirector2 == true) && ($user['mstatus'] == 'Золотой директор')){
				Income::updateStatus($user['email'],'Сапфировый директор');
				Income::updateStatusTree($user['email'],'Сапфировый директор');
				Income::premiaBonus($user['id'], $user['email'], $user['team'], $fio, 550000, 'Премия за Сапфировый директор');
			}
		}

		if((count($lc)!=0) && count($rc)!=0){
			$lDirector3 = Team::checkLeftStatus($lc, 'Сапфировый директор');
			$rDirector3 = Team::checkRightStatus($rc, 'Сапфировый директор');
			if(($lDirector3 == true) && ($rDirector3 == true) && ($user['mstatus'] == 'Сапфировый директор')){
				Income::updateStatus($user['email'],'Изумрудный директор');
				Income::updateStatusTree($user['email'],'Изумрудный директор');
				Income::premiaBonus($user['id'], $user['email'], $user['team'], $fio, 750000, 'Премия за Изумрудный директор');
			}
		}

		if((count($lc)!=0) && count($rc)!=0){
			$lDirector4 = Team::checkLeftStatus($lc, 'Изумрудный директор');
			$rDirector4 = Team::checkRightStatus($rc, 'Изумрудный директор');
			if(($lDirector4 == true) && ($rDirector4 == true) && ($user['mstatus'] == 'Изумрудный директор')){
				Income::updateStatus($user['email'],'Бриллиантовый директор');
				Income::updateStatusTree($user['email'],'Бриллиантовый директор');
				Income::premiaBonus($user['id'], $user['email'], $user['team'], $fio, 1200000, 'Премия за Бриллиантовый директор');
			}
		}



		$teams			= Team::getChilds2($userId);
		$arr 			= array();
		while($rr = $teams->fetch(PDO::FETCH_ASSOC)){
			$arr[] = $rr;
		}
		
		$arrcount = count($arr);
		$total 	= 0;
		if($user['mstatus'] == 'Директор'){
			$getDirector = Income::getIncome($user['email'], 'Оффисный Бонус за Директора');
			if(!$getDirector){
				Income::officeBonus($user['id'], $user['email'], $user['team'], $user['name'], 
									$user['surname'],50,0,'Оффисный Бонус за Директора');
			}else{
				$countL = $getDirector['countL'];
				$ostat  = $arrcount-$countL;
				$total  = $ostat*500;
				if($total != 0){
					Income::officeBonus($user['id'], $user['email'], $user['team'], $user['name'], 
										$user['surname'],$arrcount,$total,'Оффисный Бонус за Директора');
				}

			}
		}
		if($user['mstatus'] == 'Золотой директор'){
			$getDirector = Income::getIncome($user['email'], 'Оффисный Бонус за Золотого директора');
			if(!$getDirector){
				Income::officeBonus($user['id'], $user['email'], $user['team'], $user['name'], 
									$user['surname'],100,0,'Оффисный Бонус за Золотого Директора');
			}else{
				$countL = $getDirector['countL'];
				$ostat  = $arrcount-$countL;
				$total  = $ostat*700;
				if($total != 0){
					Income::officeBonus($user['id'], $user['email'], $user['team'], $user['name'], 
										$user['surname'],$arrcount,$total,'Оффисный Бонус за Золотого директора');
				}

			}
		}
		if($user['mstatus'] == 'Сапфировый директор'){
			$getDirector = Income::getIncome($user['email'], 'Оффисный Бонус за Сапфирового директора');
			if(!$getDirector){
				Income::officeBonus($user['id'], $user['email'], $user['team'], $user['name'], 
									$user['surname'],300,0,'Оффисный Бонус за Сапфирового директора');
			}else{
				$countL = $getDirector['countL'];
				$ostat  = $arrcount-$countL;
				$total  = $ostat*1000;
				if($total != 0){
					Income::officeBonus($user['id'], $user['email'], $user['team'], $user['name'], 
										$user['surname'],$arrcount,$total,'Оффисный Бонус за Сапфирового директора');
				}

			}
		}
		if($user['mstatus'] == 'Изумрудный директор'){
			$getDirector = Income::getIncome($user['email'], 'Оффисный Бонус за Изумрудного директора');
			if(!$getDirector){
				Income::officeBonus($user['id'], $user['email'], $user['team'], $user['name'], 
									$user['surname'],800,0,'Оффисный Бонус за Изумрудного директора');
			}else{
				$countL = $getDirector['countL'];
				$ostat  = $arrcount-$countL;
				$total  = $ostat*1300;
				if($total != 0){
					Income::officeBonus($user['id'], $user['email'], $user['team'], $user['name'], 
										$user['surname'],$arrcount,$total,'Оффисный Бонус за Изумрудного директора');
				}

			}
		}
		if($user['mstatus'] == 'Бриллиантовый директор'){
			$getDirector = Income::getIncome($user['email'], 'Оффисный Бонус за Бриллиантового директора');
			if(!$getDirector){
				Income::officeBonus($user['id'], $user['email'], $user['team'], $user['name'], 
									$user['surname'],2000,0,'Оффисный Бонус за Бриллиантового директора');
			}else{
				$countL = $getDirector['countL'];
				$ostat  = $arrcount-$countL;
				$total  = $ostat*1500;
				if($total != 0){
					Income::officeBonus($user['id'], $user['email'], $user['team'], $user['name'], 
										$user['surname'],$arrcount,$total,'Оффисный Бонус за Бриллиантового директора');
				}

			}
		}
        
        $pagination = new Pagination($tot, $page, Income::SHOW_BY_DEFAULT, 'page-');
        require_once(ROOT . '/views/income/index.php');
        return true;
    }
	
}