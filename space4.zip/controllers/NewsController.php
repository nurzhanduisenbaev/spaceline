<?php
class NewsController{

	public function actionIndex(){
		$userId = User::checkLogged();
		$user 	= User::getUserById($userId);
		



		require_once(ROOT . '/views/news/index.php');
		return true;
	}
	public function actionAdd(){
		$userId = User::checkLogged();
		$user 	= User::getUserById($userId);
		



		require_once(ROOT . '/views/news/add.php');
		return true;
	}
}

?>