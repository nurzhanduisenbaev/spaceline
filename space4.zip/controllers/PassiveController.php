<?php

class PassiveController{
	public function actionPassive(){
		$db = Db::getConnection();
		$sql = "SELECt *FROM tree WHERE `mright`!='' AND `mleft`!='' LIMIT 100";
		$result = $db->query($sql);
		$pass = [];
		while($row = $result->fetch(PDO::FETCH_ASSOC)){
				$pass[] = $row;			
		}
		echo '<pre>';
		print_r($pass);
		echo '</pre>';
		$total = count($pass);
		$dayInc = Income::getIncome3();
		$dayTot = 0;
		while($rinc = $dayInc->fetch(PDO::FETCH_ASSOC)){
			$dayTot+=(($rinc['total']*100)/16.07);
		}
		$dayTot = $dayTot/$total;
		$date = date('Y-m-d H:i:s');
		$sqlNew = "INSERT INTO income(`email`,`user_id`,`total`,`name`,`date`,`passive`,`team`,`fio`) VALUES ";
		foreach($pass as $passes){
			//$passes['mstatus'] = 'passive';
			//print_r($passes);
			//die();
			$sqlNew .= "('".$passes['email']."','".$passes['id']."','".$dayTot."','Пассивный доход','".$date."','".$dayTot."','".$passes['team']."','".$passes['fio']."'),";
		}
		//return 1;
		$sqlNew = substr($sqlNew,0,-1);
		//echo $sqlNew;
		$res = $db->query($sqlNew);
		require_once(ROOT . '/views/passive/passive.php');
		return true;
	}

}

?>