<?php
class ProfileController{

	public function actionIndex($id){
		$userId = User::checkLogged();
		$user 	= User::getUserById($id);
		



		require_once(ROOT . '/views/profile/index.php');
		return true;
	}
	public function actionEdit($id){
		$userId = User::checkLogged();
		$user 	= User::getUserById($id);
		



		require_once(ROOT . '/views/profile/edit.php');
		return true;
	}
	public function actionEditphoto($id){
		$userId = User::checkLogged();
		$user 	= User::getUserById($id);
		$email  = $user['email']; 
		$conn 	= Db::getConnection();
		
		//echo $_SERVER['DOCUMENT_ROOT'];
		//if(isset($_POST['add_image'])){
		$uploadOk = 1;
		// Check if image file is a actual image or fake image
		if(isset($_POST["add_image"])) {
			$target_dir = $_SERVER['DOCUMENT_ROOT']."/template/img/my-profile/";
			$target_file = $target_dir . basename($_FILES["picture"]["name"]);
			
			$name = $_FILES["picture"]["name"];
			$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
			$check = getimagesize($_FILES["picture"]["tmp_name"]);
			if($check !== false) {
				//echo "File is an image - " . $check["mime"] . ".";
				$uploadOk = 1;
			} else {
				//echo "File is not an image.";
				$uploadOk = 0;
			}
			if (file_exists($target_file)) {
				echo "<script>alert('Изображение существует в базе. Пожалуйста выберите другое изображение');window.location.href('/profile/editphoto/".$userId."');</script>";

				$uploadOk = 0;
			}
			// Check file size
			if ($_FILES["picture"]["size"] > 500000) {
				echo "<script>alert('Размер изображения слишком большой');window.location.href('/profile/editphoto/".$userId."');</script>";
				$uploadOk = 0;
			}
			// Allow certain file formats
			if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
			   && $imageFileType != "gif" ) {
				echo "<script>alert('Формат должен быть только (jpg,png,jpeg,gif)');window.location.href('/profile/editphoto/".$userId."');</script>";
				$uploadOk = 0;
			}
			// Check if $uploadOk is set to 0 by an error
			if ($uploadOk == 0) {
				echo "<script>alert('Изображение не обновлен');window.location.href('/profile/editphoto/".$userId."');</script>";
				// if everything is ok, try to upload file
			} else {
				if (move_uploaded_file($_FILES["picture"]["tmp_name"], $target_file)) {
					$conn->query("UPDATE `user` SET `image` = '$name' WHERE `user`.`email` = '$email'");
					
					
					
					header("Location: /profile/index/".$user['id']);
					
				} else {
					echo "Sorry, there was an error uploading your file.";
				}
			}
		}
		// Check if file already exists
		
			
		//}



		require_once(ROOT . '/views/profile/change_image.php');
		return true;
	}
}

?>