<?php
class ReferalController{
	public function actionReferal($id){
		$user = User::getUserById($id);
		//print_r($user);
		$users      = User::getUsersFromTree($id);
        $treeUser   = User::getTreeById($id);
		
		
        $newMass[] = $treeUser;
        while ($r = $users->fetch(PDO::FETCH_ASSOC)){
            $newMass[] = $r;
        }
        $getProduct = User::getProducts();
		
		// Храним ошибки
        $errors = false;
        $trues  = array();
        if(isset($_POST['register'])){
            $name           = $_POST['name'];
            $surname        = $_POST['surname'];
            $fathername     = $_POST['lastname'];

            $role           = $_POST['role'];
            $email          = $_POST['email'];
            $password       = $_POST['password'];

            $date_of_born   = $_POST['data_born'];
            $sex            = $_POST['sex'];
            $iin            = $_POST['iin'];
            $card           = $_POST['card'];
            $invoice        = $_POST['invoice'];
            $data_reg       = $_POST['data_reg'];

            $country        = $_POST['country'];
            $city           = $_POST['city'];
            $street         = $_POST['street'];
            $house          = $_POST['house'];
            $room           = $_POST['room'];

            $who            = $_POST['who'];
            $side           = $_POST['side'];
            $product        = $_POST['product'];
            $team           = $_POST['team'];
            //$oplata         = $_FILES['oplata'];
			$ok = false;
			$mass = array();
			$mass['name'] 		= $name;
			$mass['surname'] 	= $surname;
			$mass['fathername'] = $fathername;
			$mass['email']		= $email;
			$mass['password']	= $password;
			$mass['data_born']	= $date_of_born;
			$mass['sex']		= $sex;
			$mass['iin']		= $iin;
			$mass['card']		= $card;
			$mass['invoice']	= $invoice;
			$mass['data_reg']	= $data_reg;
			$mass['country']	= $country;
			$mass['street']		= $street;
			$mass['city']		= $city;
			$mass['house']		= $house;
			$mass['room']		= $room;
			$mass['who']		= $who;
			$mass['product']	= $product;
			$mass['team']		= $team;
            // Валидация полей
            if (!User::checkPassword($password)) {
                $errors[]  = 'Пароль не должен быть короче 6-ти символов';
            }
            if (User::checkEmailExists($email)) {
                $errors[] = 'Парнер с таким email существет';
            }
            if($errors == false){
                $trues = User::generateRegister($role, $email, $password, $user['id'], $name, $surname, $fathername,
                    $date_of_born, $iin, $sex, $card, $invoice, $data_reg, $country, $city, $street, $house, $room, $who, $product, $team,$side);
				if($trues){
					$reg = User::registerUser($trues);
					
					if($reg){
						$img 			= $_FILES["oplata"]["name"];
						$target_dir 	= $_SERVER['DOCUMENT_ROOT']."/template/img/kvitancia/";
						$target_file 	= $target_dir . basename($_FILES["oplata"]["name"]);
						if(move_uploaded_file($_FILES["oplata"]["tmp_name"], $target_file)){
							$conn->query("UPDATE `user` SET `img_invoice` = '$img' WHERE `user`.`email` = '$email'");
						}
						$user2     	= User::getUserById($who);
						$par_email 	= $user2['email'];
						$fio 		= $name.' '.$surname;
						$up 		= User::updateTreeSide($par_email, $side, $email);
						$regTree 	= User::addToTree($trues);
						$mail 		= User::mailTo($img, $mass);
						$ok 		= true;
					}
					
				}
                

            }
			if($ok){
				echo "<script>alert('Вы успешно зарегистрировались. Пожалуйста подождите.');</script>";
			}

        }
		
		//echo $_SERVER['SERVER_NAME'];
		require_once(ROOT . '/views/referal/referal.php');
		return true;
	}
}

?>