<?php


class TeamController
{
    public function actionIndex(){
        $userId = User::checkLogged();
        $user = User::getUserById($userId);
        $mass = Tree::getCategory($user);
        $tree = Tree::out_tree_checkbox($mass);
        require_once(ROOT . '/views/team/index.php');
        return true;
    }
	public function actionLich($id){
		$userId = User::checkLogged();
        $user = User::getUserById($userId);
		$takeLich = Team::takeLich($userId);
		$mass = [];
		while($rr = $takeLich->fetch(PDO::FETCH_ASSOC)){
			$mass[] = $rr;
		}
		//echo '<pre>';
		//print_r($mass);
		//echo '</pre>';
		//echo $id;
		require_once(ROOT . '/views/team/lich.php');
        return true;
	}

}