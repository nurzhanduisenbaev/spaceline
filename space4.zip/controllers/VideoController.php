<?php
class VideoController{
	public function actionIndex(){
		$userId = User::checkLogged();
        $user 	= User::getUserById($userId);
		require_once(ROOT . '/views/video/index.php');
		return true;
	}
	
}

?>