<?php


class Admin{

	public static function auth($userId)
	{
		// Записываем идентификатор пользователя в сессию
		$_SESSION['user'] = $userId;
	}

	public static function checkLogged()
	{
		// Если сессия есть, вернем идентификатор пользователя
		if (isset($_SESSION['user'])) {
			return $_SESSION['user'];
		}

		header("Location: /");
	}

	public static function isGuest()
	{
		if (isset($_SESSION['user'])) {
			return false;
		}
		return true;
	}
	public static function checkPassword($password)
	{
		if (strlen($password) >= 6) {
			return true;
		}
		return false;
	}

	public static function checkEmail($email)
	{
		if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
			return true;
		}
		return false;
	}

	public static function checkEmailExists($email)
	{
		// Соединение с БД
		$db = Db::getConnection();

		// Текст запроса к БД
		$sql = 'SELECT COUNT(*) FROM user WHERE email = :email';

		// Получение результатов. Используется подготовленный запрос
		$result = $db->prepare($sql);
		$result->bindParam(':email', $email, PDO::PARAM_STR);
		$result->execute();

		if ($result->fetchColumn()) {
			return true;
		}
		return false;
	}
	public static function checkUserData($email, $password)
    {
        // Соединение с БД
        $db = Db::getConnection();

        // Текст запроса к БД
        $sql = "SELECT * FROM user WHERE email = :email AND password = :password AND role = 'Супер-Админ'";

        // Получение результатов. Используется подготовленный запрос
        $result = $db->prepare($sql);
        $result->bindParam(':email', $email, PDO::PARAM_STR);
        $result->bindParam(':password', $password, PDO::PARAM_INT);
        $result->execute();

        // Обращаемся к записи
        $user = $result->fetch();

        if ($user) {
            // Если запись существует, возвращаем id пользователя
            return $user['id'];
        }
        return false;
    }
	public static function getUserById($id)
    {
        // Соединение с БД
        $db = Db::getConnection();

        // Текст запроса к БД
        $sql = 'SELECT * FROM user WHERE id = :id';

        // Получение и возврат результатов. Используется подготовленный запрос
        $result = $db->prepare($sql);
        $result->bindParam(':id', $id, PDO::PARAM_INT);

        // Указываем, что хотим получить данные в виде массива
        $result->setFetchMode(PDO::FETCH_ASSOC);
        $result->execute();

        return $result->fetch();
    }
	public static function takeT(){
		$db 	= Db::getConnection();
		$sql 	= "SELECT *FROM takes WHERE status='0'";
		$result = $db->query($sql);
		return $result;
	}
	public static function takeU(){
		$db 	= Db::getConnection();
		$sql 	= "SELECT *FROM user WHERE `access`='запрещен' AND `product`!='не указан'";
		$result = $db->query($sql);
		return $result;
	}
	public static function takeM(){
		$db 	= Db::getConnection();
		$sql 	= "SELECT *FROM takes WHERE status='2'";
		$result = $db->query($sql);
		return $result;
	}
	public static function takeIncome(){
		$db 	= Db::getConnection();
		$sql 	= "SELECT *FROM income WHERE name='Личный Бонус'";
		$result = $db->query($sql);
		return $result;
	}
	public static function takeCount(){
		$db 	= Db::getConnection();
		$sql 	= "SELECT COUNT(id) FROM user WHERE `id` NOT IN(1,2) AND `product`!='не указан'";
		$result = $db->query($sql);
		return $result;
	}
	public static function takeAccount(){
		$db 	= Db::getConnection();
		$sql 	= "SELECT COUNT(id) FROM user WHERE `id` NOT IN(1,2)";
		$result = $db->query($sql);
		return $result;
	}
	public static function takeCountLider(){
		$db 	= Db::getConnection();
		$sql 	= "SELECT COUNT(id) FROM user WHERE `role` != 'Партнер' AND `role` != 'Супер-Админ'";
		$result = $db->query($sql);
		return $result;
	}
}
?>