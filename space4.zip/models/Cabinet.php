<?php


class Cabinet
{
    public static function getMoney($user_id,$email,$fio,$date,$sum,$invoice,$iin,$card){
		$db = Db::getConnection();        
        $sql            = "INSERT INTO takes(email,user_id,fio,date,sum,invoice,iin,card)
                        VALUES ('$email', '$user_id','$fio', '$date', '$sum','$invoice','$iin','$card')";
        $result = $db->prepare($sql);
        $result->execute();
        return $result;
	}
	public static function getUsers(){
        // Соединение с БД
        $db = Db::getConnection();
		$date1 = date("Y-m-01 00:00:00");
		$date2 = date("Y-m-30 23:59:59");
        $sql = "SELECT * FROM tree WHERE `data_reg` BETWEEN '$date1' AND '$date2'";
        $result = $db->query($sql);
        return $result;
    }
	public static function mailToAdmin($fio,$invoice,$email,$date,$summ){
		//$to      = 'info@spaceline.kz';
		$to      = 'info@spaceline.kz';
		$subject = 'Запрос на выплаты';
		$message = "Вы получили запрос на вывод средства от пользователя $fio на сумму $summ тенге перейдите в кабинет админа в раздел ВЫПЛАТЫ ";
		$headers = 'From:  info@spaceline.kz' . "\r\n" .
				   'Reply-To:  info@spaceline.kz' . "\r\n" .
				   'X-Mailer: PHP/' . phpversion();

		$mail = mail($to, $subject, $message, $headers);
		if($mail){
			return true;
		}else{
			return false;
		}
	}
	public static function mailToBuch(){
		$to      = 'buh@spaceline.kz';
		//$to      = 'nurzhanduisenbaev480@mail.ru';
		$subject = 'Запрос на выплату';
		$message = 'Выплатить';
		$headers = 'From: info@spaceline.kz' . "\r\n" .
				   'Reply-To: info@spaceline.kz' . "\r\n" .
				   'X-Mailer: PHP/' . phpversion();

		$mail = mail($to, $subject, $message, $headers);
		if($mail){
			return true;
		}else{
			return false;
		}
	}

}