<?php


class Income
{
    const SHOW_BY_DEFAULT = 10;
    public static function selfBonus($user_id, $email, $team, $product, $name, $surname){
        $db = Db::getConnection();
        $packet         = 0;
        $total          = 0;
        $fio            = $name.' '.$surname;
        $date_of_income = date("Y-m-d H:i");
        $product_info   = User::getProduct($product);
        $product_price  = $product_info['product_price'];
		$product_count  = $product_info['product_count'];
        $packet         = ($product_price*16.07)/100;
        $total          = $packet;
        $sql            = "INSERT INTO income(email,user_id,total,packet,name,date,team,fio,countL)
                        VALUES ('$email', '$user_id','$total', '$packet', 'Личный Бонус', '$date_of_income','$team','$fio','$product_count')";
        $result = $db->prepare($sql);
        $result->execute();
        return $result;
    }
	public static function getIncome8($email){
        // Соединение с БД
        $db = Db::getConnection();
		
        $sql = "SELECT * FROM income WHERE `name`='Пассивный доход' AND `email`='$email' ORDER BY id DESC LIMIT 1";
        $result = $db->query($sql);
        return $result;
    }
	public static function getIncome9($email){
        // Соединение с БД
        $db = Db::getConnection();
		
        $sql = "SELECT * FROM income WHERE `name`='Пассивный доход' AND `email`='$email'";
        $result = $db->query($sql);
        return $result;
    }
	public static function getIncome7($email){
        // Соединение с БД
        $db = Db::getConnection();
		
        $sql = "SELECT * FROM income WHERE `email`='$email' AND `name`!='Выплаты'";
        $result = $db->query($sql);
        return $result;
    }
	public static function getIncome6($email){
        // Соединение с БД
        $db = Db::getConnection();
		
        $sql = "SELECT * FROM income WHERE email='$email'";
        $result = $db->query($sql);
        return $result;
    }
	public static function getIncome5($id){
        // Соединение с БД
        $db = Db::getConnection();
		$team = Team::getChilds($id);
		$arr[0] = $id; 
		$array_index = array();
		while($r = $team->fetch(PDO::FETCH_ASSOC)){
			$array_index[] = $r['id'];
		}
		$result = array_merge($arr,$array_index);
		$str 	= implode(',',$result);
        $sql = "SELECT * FROM income WHERE `name`='Личный Бонус' AND `user_id` IN($str)";
        $result = $db->query($sql);
        return $result;
    }
	public static function getIncome4($email){
        // Соединение с БД
        $db = Db::getConnection();
		$date1 = date("Y-m-d 08:00:00");
		$date2 = date("Y-m-d 23:59:59");
        $sql = "SELECT * FROM income WHERE `name`='Личный Бонус' AND email='$email'";
        $result = $db->query($sql);
        return $result;
    }
	public static function getIncome3(){
        // Соединение с БД
        $db = Db::getConnection();
		$date1 = date("Y-m-d 08:00:00");
		$date2 = date("Y-m-d 23:59:59");
        $sql = "SELECT * FROM income WHERE `name`='Личный Бонус' AND date BETWEEN '$date1' AND '$date2'";
        $result = $db->query($sql);
        return $result;
    }
	public static function getIncome2($email, $page){
        // Соединение с БД
        $db 	= Db::getConnection();
		$limit 	= self::SHOW_BY_DEFAULT;
		$offset = ($page - 1) * self::SHOW_BY_DEFAULT;

        $sql = "SELECT *FROM income WHERE `email`='$email' ORDER BY id DESC LIMIT $limit OFFSET $offset";
		$result = $db->query($sql);
        // Используется подготовленный запрос
        //$result = $db->prepare($sql);
        //$result->bindParam(':category_id', $email, PDO::PARAM_STR);
        //$result->bindParam(':limit', $limit, PDO::PARAM_INT);
        //$result->bindParam(':offset', $offset, PDO::PARAM_INT);

        // Выполнение коменды
        //$result->execute();

        // Получение и возврат результатов
        $i = 0;
        $products = array();
        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
            $products[] = $row;
        }
        return $products;
    }
    public static function getIncome($email, $name){
        $db = Db::getConnection();
        $sql = 'SELECT * FROM income WHERE email = :email AND name = :name ORDER BY id DESC LIMIT 1';
        $result = $db->prepare($sql);
        $result->bindParam(':email', $email, PDO::PARAM_STR);
        $result->bindParam(':name', $name, PDO::PARAM_STR);
        $result->execute();
        // Обращаемся к записи
        $income_info = $result->fetch();
        return $income_info;
    }
    public static function getTotalIncome(){
        // Соединение с БД
        $db = Db::getConnection();

        $sql = 'SELECT count(id) AS count FROM income';
        $result = $db->prepare($sql);
        $result->execute();
        $row = $result->fetch();
        return $row['count'];
    }
    public static function getIncomes(){
        // Соединение с БД
        $db = Db::getConnection();

        $sql = 'SELECT * FROM income';
        $result = $db->query($sql);
        return $result;
    }
    public static function bothBonus($user_id, $email, $team, $name, $surname,$countL=0,$countR=0,$total=0){
        $db = Db::getConnection();
        //$total          = 0;
        $fio            = $name.' '.$surname;
        $date_of_income = date("Y-m-d H:i");
        $sql            = "INSERT INTO income(email,user_id,total,name,date,team,fio,countL,countR)
        VALUES ('$email', '$user_id','$total', 'Парный Бонус', '$date_of_income','$team','$fio','$countL','$countR')";
        $result = $db->prepare($sql);
        $result->execute();
        return $result;
    }
	public static function bothBonusForBilet($user_id, $email, $team, $name, $surname,$countL=0,$countR=0,$total=0){
        $db = Db::getConnection();
        //$total          = 0;
		$total			= -$total;
        $fio            = $name.' '.$surname;
        $date_of_income = date("Y-m-d H:i");
        $sql            = "INSERT INTO income(email,user_id,total,name,date,team,fio,countL,countR)
        VALUES ('$email', '$user_id','$total', 'Парный Бонус(Минус за Билет)', '$date_of_income','$team','$fio','$countL','$countR')";
        $result = $db->prepare($sql);
        $result->execute();
        return $result;
    }
    public static function quickBonus($user_id, $email, $team, $name, $surname,$countL=0,$total=0){
        $db = Db::getConnection();
        //$total          = 0;
        $fio            = $name.' '.$surname;
        $date_of_income = date("Y-m-d H:i");
        $sql            = "INSERT INTO income(email,user_id,total,name,date,team,fio,countL)
        VALUES ('$email', '$user_id','$total', 'Бонус Быстрый Старт', '$date_of_income','$team','$fio','$countL')";
        $result = $db->prepare($sql);
        $result->execute();
        return $result;
    }
    public static function liderBonus($user_id, $email, $team, $fio, $total=0){
        $db = Db::getConnection();
        //$total          = 0;
        //$fio            = $name.' '.$surname;
        $date_of_income = date("Y-m-d H:i");
        $sql            = "INSERT INTO income(email,user_id,total,name,date,team,fio)
        VALUES ('$email', '$user_id','$total', 'Лидерский Бонус','$date_of_income','$team','$fio')";
        $result = $db->prepare($sql);
        $result->execute();
        return $result;
    }
	public static function premiaBonus($user_id, $email, $team, $fio, $total=0, $premia){
        $db = Db::getConnection();
        //$total          = 0;
        //$fio            = $name.' '.$surname;
        $date_of_income = date("Y-m-d H:i");
        $sql            = "INSERT INTO income(email,user_id,total,name,date,team,fio)
        VALUES ('$email', '$user_id','$total', '$premia','$date_of_income','$team','$fio')";
        $result = $db->prepare($sql);
        $result->execute();
        return $result;
    }
    
    public static function updateBilet($email,$bilet){
        $db = Db::getConnection();
        // Текст запроса к БД
        $sql = "UPDATE user SET bilet = :bilet WHERE email = :email";
        // Получение и возврат результатов. Используется подготовленный запрос
        $result = $db->prepare($sql);
        $result->bindParam(':email', $email, PDO::PARAM_STR);
        $result->bindParam(':bilet', $bilet, PDO::PARAM_INT);

        return $result->execute();
    }
    public static function updateStatus($email,$status){
        $db = Db::getConnection();
        // Текст запроса к БД
        $sql = "UPDATE user SET mstatus = :status WHERE email = :email";
        // Получение и возврат результатов. Используется подготовленный запрос
        $result = $db->prepare($sql);
        $result->bindParam(':email', $email, PDO::PARAM_STR);
        $result->bindParam(':status', $status, PDO::PARAM_STR);

        return $result->execute();
    }
	public static function updateStatusTree($email,$status){
        $db = Db::getConnection();
        // Текст запроса к БД
        $sql = "UPDATE tree SET rstatus = :status WHERE email = :email";
        // Получение и возврат результатов. Используется подготовленный запрос
        $result = $db->prepare($sql);
        $result->bindParam(':email', $email, PDO::PARAM_STR);
        $result->bindParam(':status', $status, PDO::PARAM_STR);

        return $result->execute();
    }
    public static function quickBonusAlgorithm($id){
        $db 	= Db::getConnection();
        $users 	= Team::getChilds($id);
        $d 		= $users->fetch(PDO::FETCH_ASSOC);
        $data       = $d['data_reg'];
        //$old_date = '05-06-2016';
        $next_date  = date('Y-m-d', strtotime($data. ' +30 days'));
        //echo $next_date;
        $sql = "SELECT *FROM tree WHERE `user_id`='$id' AND packet !='Пакет Start' AND `data_reg` BETWEEN '$data' AND '$next_date'";
        $result = $db->query($sql);
        $mass = array();
        while($r = $result->fetch(PDO::FETCH_ASSOC)){
            $mass[] = $r;
        }
        //return $mass;
        $userId     = User::checkLogged();
        $user       = User::getUserById($id);
        $q 			= Income::getIncome($user['email'], 'Бонус Быстрый Старт');
        $countMass  = count($mass);
        $total = 0;
        if($q){
            $countL = $q['countL'];
            if($countMass>=4){
                $ostatka = $countMass-$countL;
                $total = ((int)(($countMass-$countL)/4))*30000;
                if($total != 0){
                    self::quickBonus($user['id'],$user['email'],$user['team'],$user['name'],$user['surname'],$ostatka,$total);
                }
            }
        }else{
            $total = ((int)(($countMass)/4))*30000;
			if($total!=0){
				self::quickBonus($user['id'],$user['email'],$user['team'],$user['name'],$user['surname'],$countMass,$total);
			}

        }
        return true;
    }
    public static function liderBonusAlgorithm($id, $product, $fio){
        $total 			= 0;
		$user 			= User::getUserById($id);
		$par_user 		= User::getUserById($user['user_id']);
        $product_data   = User::getProduct($product);
        $product_price  = $product_data['product_price'];
        if($par_user['id'] != 1){
           $total = ((($product_price*16.07)/100)*10)/100;
           if($total != 0){
               self::liderBonus($par_user['id'],$par_user['email'],$par_user['team'], $fio, $total);
           }
        }
        return true;
    }
	public static function newUserBonusN($product){
		$mass1   = array();
		$mass2   = array();
		$mass3   = array();
		$mass4   = array();
		$mass5   = array();
		$date	 = date("Y-m-d H:i:s");
		$db      = Db::getConnection();
		$sql1    = "SELECT *FROM user WHERE mstatus='Директор'";
		$result1 = $db->query($sql1);
		$sql2    = "SELECT *FROM user WHERE mstatus='Директор'";
		$result2 = $db->query($sql1);
		$insertSql = "INSERT INTO income(email,user_id,total,name,date,team,fio)
		VALUES ";
		if($result1){
			$total = $product_price*500;
			while($row1 = $result1->fetch(PDO::FETCH_ASSOC)){
				$fio = $name.' '.$surname;
				$insertSql .= "('"
					.$row1['email']."','".$row1['id']."','".$total."','".'Личный бонус от нового пользователя'."','"
					.$date."','".$row1['team']."','".$fio."'),";
			}
			$insertSql 	= substr($insertSql, 0, -1);
			$resultQ 	= $db->prepare($insertSql);
			$resultQ->execute();
		}

	}
	////
	public static function officeBonus($user_id, $email, $team, $name, $surname,$countL=0,$total=0,$income_name){
        $db = Db::getConnection();
        //$total          = 0;
        $fio            = $name.' '.$surname;
        $date_of_income = date("Y-m-d H:i");
        $sql            = "INSERT INTO income(email,user_id,total,name,date,team,fio,countL)
        VALUES ('$email', '$user_id','$total', '$income_name','$date_of_income','$team','$fio','$countL')";
        $result = $db->prepare($sql);
        $result->execute();
        return $result;
    }
	public static function getTotalProductsInCategory($categoryId)
    {
        $db = Db::getConnection();

        // Текст запроса к БД
        $sql = 'SELECT count(id) AS count FROM income WHERE `email` = :category_id';

        // Используется подготовленный запрос
        $result = $db->prepare($sql);
        $result->bindParam(':category_id', $categoryId, PDO::PARAM_STR);

        // Выполнение коменды
        $result->execute();

        // Возвращаем значение count - количество
        $row = $result->fetch();
        return $row['count'];
    }
	public static function viplaty($user_id, $email, $team, $fio, $total=0){
        $db = Db::getConnection();
        //$total          = 0;
        //$fio            = $name.' '.$surname;
		$total = -$total;
        $date_of_income = date("Y-m-d H:i");
        $sql            = "INSERT INTO income(email,user_id,total,name,date,team,fio)
        VALUES ('$email', '$user_id','$total','Выплаты','$date_of_income','$team','$fio')";
        $result = $db->prepare($sql);
        $result->execute();
        return $result;
    }
	public static function upTake($status,$email){
		$db = Db::getConnection();
        // Текст запроса к БД
        $sql = "UPDATE takes SET status = :status WHERE email = :email";
        // Получение и возврат результатов. Используется подготовленный запрос
        $result = $db->prepare($sql);
        $result->bindParam(':email', $email, PDO::PARAM_STR);
        $result->bindParam(':status', $status, PDO::PARAM_INT);

        return $result->execute();
		
	}

}
