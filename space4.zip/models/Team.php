<?php


class Team
{
    public $userId      = 0;
    public $leftUserId  = 0;
    public $rightUserId = 0;
    public $leftCount   = 0;
    public $rightCount  = 0;
	const SHOW_BY_DEFAULT = 10;
    public function __construct()
    {
        $this->userId   = User::checkLogged();
        $user           = User::getUserById($this->userId);
//        $treeUser       = User::getTreeById($this->userId);
//        $leftEmail      = $treeUser['mleft'];
//        $rightEmail     = $treeUser['mright'];
//        if(!isset($leftEmail)){
//            $lEmail = User::getTreeByEmail($leftEmail);
//            $this->leftUserId = $lEmail['id'];
//            self::getLeftChilds($this->leftUserId);
//        }
//        if(!isset($rightEmail)){
//            $rEmail = User::getTreeByEmail($rightEmail);
//            $this->rightUserId = $rEmail['id'];
//            self::getRightChilds($this->rightUserId);
//        }
    }

    public static function getChilds($id){
        // Соединение с БД
        $db = Db::getConnection();
        $sql = "select *from (select * from tree order by parent_id, id) folders_sorted,
        (select @pv := '$id') initialisation 
        where find_in_set(parent_id, @pv) > 0 and `access`='разрешен'
        and @pv := concat(@pv, ',', id)";
        $result = $db->query($sql);
        return $result;
    }
	public static function getChilds2($id){
        // Соединение с БД
        $db = Db::getConnection();
        $sql = "select *from (select * from tree order by parent_id, id) folders_sorted,
        (select @pv := '$id') initialisation 
        where find_in_set(parent_id, @pv) > 0 
        and `packet`!='Пакет Start' and `access`='разрешен' and @pv := concat(@pv, ',', id)";
        $result = $db->query($sql);
        return $result;
    }
    public static function getLeftChilds($data){
        $childs = array();
        if(!empty($data)){
            $childs[] = $data;
        }
        $left_info = self::getChilds($data['id']);
        while($row=$left_info->fetch(PDO::FETCH_ASSOC)){
            $childs[] = $row;
        }
        return $childs;
    }
    public static function getRightChilds($data){
        $right_info = self::getChilds($data['id']);
        $childs = array();
        if(!empty($data)){
            $childs[] = $data;
        }
        while($row=$right_info->fetch(PDO::FETCH_ASSOC)){
            $childs[] = $row;
        }
        return $childs;
    }
	public static function takeLich($id){
        $db = Db::getConnection();
        $sql = 'SELECT * FROM tree WHERE user_id = :user_id';
        $result = $db->prepare($sql);
        $result->bindParam(':user_id', $id, PDO::PARAM_INT);
        $result->execute();
        //$result->fetch(PDO::FETCH_ASSOC);
        return $result;
    }
    public static function takeChild($email){
        $db = Db::getConnection();
        $sql = 'SELECT * FROM childcounts WHERE email = :email';
        $result = $db->prepare($sql);
        $result->bindParam(':email', $email, PDO::PARAM_STR);
        $result->execute();
        $income_info = $result->fetch();
        return $income_info;
    }
    public static function insertChild($countL,$countR,$email){
        $db = Db::getConnection();
        $sql            = "INSERT INTO childcounts(email,countL,countR) VALUES ('$email','$countL','$countR')";
        $result = $db->prepare($sql);
        $result->execute();
        return $result;
    }
    public static function updateChild($countL,$countR,$email){
        $db = Db::getConnection();
        // Текст запроса к БД
        $sql = "UPDATE childcounts SET countL = :countL, countR = :countR WHERE email = :email";
        // Получение и возврат результатов. Используется подготовленный запрос
        $result = $db->prepare($sql);
        $result->bindParam(':email', $email, PDO::PARAM_STR);
        $result->bindParam(':countL', $countL, PDO::PARAM_INT);
        $result->bindParam(':countR', $countR, PDO::PARAM_INT);
        return $result->execute();
    }
	public static function checkLeftStatus($lc,$name){
		foreach($lc as $user){
			if($user['rstatus'] == $name){
				return true;
			}
		}
		return false;
	}
	public static function checkRightStatus($rc,$name){
		foreach($rc as $user){
			if($user['rstatus'] == $name){
				return true;
			}
		}
		return false;
	}
	public static function usersAll($page=1){
		$limit = self::SHOW_BY_DEFAULT;
        // Смещение (для запроса)
        $offset = ($page - 1) * self::SHOW_BY_DEFAULT;

        // Соединение с БД
        $db = Db::getConnection();

        // Текст запроса к БД
        $sql = "SELECT *FROM user WHERE product!='не указан' AND id!='1' LIMIT :limit OFFSET :offset";

        // Используется подготовленный запрос
        $result = $db->prepare($sql);
        $result->bindParam(':limit', $limit, PDO::PARAM_INT);
        $result->bindParam(':offset', $offset, PDO::PARAM_INT);

        // Выполнение коменды
        $result->execute();

        // Получение и возврат результатов
        $i = 0;
        $products = array();
        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
            $products[] = $row;
        }
        return $products;
	}
	public static function usersAllCount(){
	
        // Соединение с БД
        $db = Db::getConnection();

        // Текст запроса к БД
        $sql = "SELECT *FROM user WHERE product!='не указан'";
		$result = $db->query($sql);
        $products = array();
        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
            $products[] = $row;
        }
        return $products;
	}
	public static function incomeAll($page=1){
		$limit = self::SHOW_BY_DEFAULT;
        // Смещение (для запроса)
        $offset = ($page - 1) * self::SHOW_BY_DEFAULT;

        // Соединение с БД
        $db = Db::getConnection();

        // Текст запроса к БД
        $sql = "SELECT *FROM income WHERE `total`!='0' LIMIT :limit OFFSET :offset";

        // Используется подготовленный запрос
        $result = $db->prepare($sql);
        $result->bindParam(':limit', $limit, PDO::PARAM_INT);
        $result->bindParam(':offset', $offset, PDO::PARAM_INT);

        // Выполнение коменды
        $result->execute();

        // Получение и возврат результатов
        $i = 0;
        $products = array();
        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
            $products[] = $row;
        }
        return $products;
	}
	public static function incomeAllCount(){
	
        // Соединение с БД
        $db = Db::getConnection();

        // Текст запроса к БД
        $sql = "SELECT *FROM income WHERE `total`!='0' ORDER BY id DESC";
		$result = $db->query($sql);
        $products = array();
        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
            $products[] = $row;
        }
        return $products;
	}
}