<?php

class Tree {
    public static function getCategory($user){
        $db = Db::getConnection();
        $id = $user['id'];
        $mass[] = $user;
        $sth = $db->prepare("select *from (select * from tree order by parent_id, id) folders_sorted,
        (select @pv := '$id') initialisation 
        where find_in_set(parent_id, @pv) > 0 
        and @pv := concat(@pv, ',', id)");
		$mass[0]['parent_id'] = 0;
        $sth->execute();
        $category = $sth->fetchAll(PDO::FETCH_ASSOC);
		if(!empty($category)){
			$category = array_merge($mass,$category);
		}else{
			$category = $mass;
		}
        
        $category = self::convert($category);
        return $category;
    }
    public static function convert($array, $i = 'id', $p = 'parent_id'){
        if (!is_array($array)) {
            return array();
        } else {
            $ids = array();
            foreach ($array as $k => $v) {
                if (is_array($v)) {
                    if ((isset($v[$i]) || ($i === false)) && isset($v[$p])) {
                        $key = ($i === false) ? $k : $v[$i];
                        $parent = $v[$p];
                        $ids[$parent][$key] = $v;
                    }
                }
            }

            return (isset($ids[0])) ? self::convert_node($ids, 0, 'children') : false;
        }
    }
    public static function convert_node($index, $root, $cn){
        $_ret = array();
        foreach ($index[$root] as $k => $v) {
            $_ret[$k] = $v;
            if (isset($index[$k])) {
                $_ret[$k][$cn] = self::convert_node($index, $k, $cn);
            }
        }

        return $_ret;
    }
    public static function out_tree_checkbox($array, $first = true){
        if ($first) {
            $out = '<ul id="tree-checkbox" class="treeview">';
        } else {
            $out = '<ul>';
        }

        foreach ($array as $row) {
            $out .= '<li>';
            $out .= $row['email'];
            if (isset($row['children'])) {
                $out .= self::out_tree_checkbox($row['children'], false);
            }
            $out .= '</li>';
        }
        $out .= '</ul>';

        return $out;
    }

}

?>