<?php

/**
 * Класс User - модель для работы с пользователями
 */
class User
{
    //private $index = 0;
    /**
     * Регистрация пользователя
     * @return boolean <p>Результат выполнения метода</p>
     */
    public static function addToTree($array)
    {
        $db = Db::getConnection();

        $sql = "INSERT INTO tree (`id`,`email`,`parent_id`,`user_id`,`mleft`,`mright`,
                `fio`,`packet`,`team`,`level`,`data_reg`,`group_id`) VALUES ";
        foreach ($array as $item){
            if(!isset($item['product'])){
                $item['product'] = 'не указан';
            }
            if(!isset($item['mleft'])){
                $item['mleft'] = null;
            }
            if(!isset($item['mright'])){
                $item['mright'] = null;
            }
            $sql .= "('"
                .$item['id']."','".$item['email']."','".$item['parent_id']."','".$item['user_id']."','"
                .$item['mleft']."','".$item['mright']."','".$item['fio']."','"
                .$item['product']."','".$item['team']."','".$item['level']."','".$item['data_reg']."','".$item['group_id']."'),";
        }
        $sql = substr($sql, 0, -1);
        $result = $db->prepare($sql);
        $result->execute();
        return $sql;
    }
    public static function registerUser($array)
    {
        $db = Db::getConnection();

        $sql = "INSERT INTO user (`id`,`email`,`password`,`name`,`surname`,`lastname`,`parent_id`,`user_id`,
                    `role`,`mstatus`,`iin`,`card`,`invoice`,`data_reg`,`product`,`who`,`team`,
                    `country`,`city`,`street`,`house`,`room`,`sex`,`data_born`,`group_id`,`side`) 
                VALUES ";
        foreach ($array as $item){
            if(!isset($item['product'])){
                $item['product'] = 'не указан';
            }
            $sql .= "('"
                .$item['id']."','".$item['email']."','".$item['password']."','".$item['name']."','"
                .$item['surname']."','".$item['lastname']."','".$item['parent_id'] ."','".$item['user_id']."','".$item['role']."','"
                .$item['mstatus']."','".$item['iin']."','".$item['card']."','".$item['invoice']."','".$item['data_reg']."','"
                .$item['product']."','".$item['who'] ."','".$item['team']."','".$item['country']."','".$item['city']."','"
				.$item['street']."','".$item['house']."','".$item['room']."','".$item['sex']."','".$item['data_born']."','"
				.$item['group_id']."','".$item['side']."'),";
        }
        $sql = substr($sql, 0, -1);
        $result = $db->prepare($sql);
        $result->execute();
        return $sql;
    }

    public static function updateTreeSide($parent_email,$side, $email)
    {
        // Соединение с БД
        $db = Db::getConnection();
        // Текст запроса к БД
        $sql = "UPDATE tree SET `$side` = :email WHERE email = :parent_email";

        // Получение и возврат результатов. Используется подготовленный запрос
        $result = $db->prepare($sql);
        $result->bindParam(':email', $email, PDO::PARAM_STR);
        $result->bindParam(':parent_email', $parent_email, PDO::PARAM_STR);
        return $result->execute();
    }
    public static function generateRegister($role, $email, $password, $parent_id, $name, $surname, $fathername,
                                            $date_of_born, $iin, $sex,$card,$invoice,$data_reg,
                                            $country,$city, $street, $house, $room,
                                            $who, $product, $team,$side){
        $last   = self::lastID();
        $lastID = $last['id'];
		$groupID = $lastID+1;
        $treeMan = self::getTreeById($who);
        $level = $treeMan['level'];
        $nextLevel = $level+1;
        $first  = $lastID;
        $pr = self::getProduct($product);
        $product_count = $pr['product_count'];
        $fio = $name.' '.$surname;
        $status = 'Партнер';
        if(($lastID%2) == 0){
            $lastID = $lastID + 1;
            //$level++;
        }else{
            $lastID = $lastID + 2;
        }
        $new_tree_id = $lastID - 1;
        $mass = array([
            'parent_id' => $who,
			'group_id'	=> $groupID,
            'password'  => $password,
            'mstatus'   => $status,
            'user_id'   => $parent_id,
            'id'   		=> $lastID,
            'email'     => $email,
            'fio'       => $fio,
            'team'      => $team,
            'date'  	=> $data_reg,
            'data_reg'  => $data_reg,
            'product'   => $product,
            'who'       => $who,
            'mleft'     => '',
            'mright'    => '',
            'role'      => $role,
            'name'      => $name,
            'surname'   => $surname,
            'lastname'  => $fathername,
            'data_born' => $date_of_born,
            'iin'       => $iin,
            'sex'       => $sex,
            'card'      => $card,
            'invoice'   => $invoice,
            'country'   => $country,
            'city'      => $city,
            'street'    => $street,
            'house'     => $house,
            'room'      => $room,
            'level'     => $nextLevel,
			'side'		=> $side,
        ]);
        if($product_count != 1){
            for($i=1;$i<$product_count;$i++){
                if(($lastID%2) != 0){
                    $new_tree_id++;
                    $nextLevel++;
                }
                $lastID++;
                $new_email      = $i.''.$email;
                $new_name       = $i.''.$name;
                $new_surname    = $i.''.$surname;
                $new_lastname   = $i.''.$fathername;
                $new_fio   = $i.''.$fio;
                $mass[$i]['parent_id']  = $new_tree_id;
				$mass[$i]['group_id']	= $groupID;
                $mass[$i]['password']   = $password;
                $mass[$i]['role']       = $role;
                $mass[$i]['mstatus']    = $status;
                $mass[$i]['id']    		= $lastID;
                $mass[$i]['user_id']    = $parent_id;
                $mass[$i]['who']        = $who;
                $mass[$i]['email']      = $new_email;
                $mass[$i]['name']       = $new_name;
                $mass[$i]['surname']    = $new_surname;
                $mass[$i]['lastname']   = $new_lastname;
                $mass[$i]['fio']        = $new_fio;
                $mass[$i]['team']       = $team;
                $mass[$i]['date']   	= $data_reg;
                $mass[$i]['data_reg']   = $data_reg;
                $mass[$i]['level']      = $nextLevel;
                $mass[$i]['iin']        = $iin;
                $mass[$i]['card']       = $card;
                $mass[$i]['invoice']    = $invoice;
                $mass[$i]['country']    = $country;
                $mass[$i]['city']       = $city;
                $mass[$i]['street']     = $street;
                $mass[$i]['house']      = $house;
                $mass[$i]['sex']        = $sex;
                $mass[$i]['data_born']  = $date_of_born;
                $mass[$i]['room']       = $room;
				$mass[$i]['side']       = $side;
            }

            for($j=0; $j<count($mass); $j++){
                $t=array();
                for($k=1;$k<count($mass);$k++){
                    if($mass[$j]['id'] == $mass[$k]['parent_id']){
                        $t[] = $k;
                        if(isset($t[0])){
                            $mass[$j]['mleft']  = $mass[$t[0]]['email'];
                            $mass[$j]['mright'] = null;
                            //$mass[$j]['level']  = $nextLevel+1;
                        }
                        if(isset($t[1])){
                            $mass[$j]['mright'] = $mass[$t[1]]['email'];
                            //$mass[$j]['level']  = $nextLevel+1;
                        }
                    }
                }
                if(empty($t)){
                    $mass[$j]['mleft']  = '';
                    $mass[$j]['mright'] = '';
                }
            }
        }
        return $mass;
    }


    public static function getProduct($product){
        $db = Db::getConnection();

        // Текст запроса к БД
        $sql = 'SELECT * FROM product WHERE product_name = :product_name';

        // Получение результатов. Используется подготовленный запрос
        $result = $db->prepare($sql);
        $result->bindParam(':product_name', $product, PDO::PARAM_STR);
        $result->execute();
        // Обращаемся к записи
        $product_info = $result->fetch();
        return $product_info;
    }
	public static function getTeam($team){
        $db = Db::getConnection();

        // Текст запроса к БД
        $sql = 'SELECT * FROM team WHERE name = :name';

        // Получение результатов. Используется подготовленный запрос
        $result = $db->prepare($sql);
        $result->bindParam(':name', $team, PDO::PARAM_STR);
        $result->execute();
        // Обращаемся к записи
        $product_info = $result->fetch();
        return $product_info;
    }
    public static function checkSide($email, $side){
        $db = Db::getConnection();

        $sql = 'SELECT  FROM tree WHERE email = :email';
        // Получение и возврат результатов. Используется подготовленный запрос
        $result = $db->prepare($sql);
        $result->bindParam(':email', $email, PDO::PARAM_STR);

        // Указываем, что хотим получить данные в виде массива
        $result->setFetchMode(PDO::FETCH_ASSOC);
        $result->execute();

        $user = $result->fetch();

        $sideValue = $user[$side];

        if($sideValue == ''){
            return true;
        }
        return false;
    }

    public static function edit($id, $name, $password)
    {
        // Соединение с БД
        $db = Db::getConnection();

        // Текст запроса к БД
        $sql = "UPDATE user SET name = :name, password = :password WHERE id = :id";

        // Получение и возврат результатов. Используется подготовленный запрос
        $result = $db->prepare($sql);
        $result->bindParam(':id', $id, PDO::PARAM_INT);
        $result->bindParam(':name', $name, PDO::PARAM_STR);
        $result->bindParam(':password', $password, PDO::PARAM_STR);
        return $result->execute();
    }

    public static function checkUserData($email, $password)
    {
        // Соединение с БД
        $db = Db::getConnection();

        // Текст запроса к БД
        $sql = "SELECT * FROM user WHERE email = :email AND password = :password AND access='разрешен'";

        // Получение результатов. Используется подготовленный запрос
        $result = $db->prepare($sql);
        $result->bindParam(':email', $email, PDO::PARAM_STR);
        $result->bindParam(':password', $password, PDO::PARAM_INT);
        $result->execute();

        // Обращаемся к записи
        $user = $result->fetch();

        if ($user) {
            // Если запись существует, возвращаем id пользователя
            return $user['id'];
        }
        return false;
    }

    public static function auth($userId)
    {
        // Записываем идентификатор пользователя в сессию
        $_SESSION['user'] = $userId;
    }

    public static function checkLogged()
    {
        // Если сессия есть, вернем идентификатор пользователя
        if (isset($_SESSION['user'])) {
            return $_SESSION['user'];
        }

        header("Location: /");
    }

    public static function isGuest()
    {
        if (isset($_SESSION['user'])) {
            return false;
        }
        return true;
    }
    public static function checkPassword($password)
    {
        if (strlen($password) >= 6) {
            return true;
        }
        return false;
    }

    public static function checkEmail($email)
    {
        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return true;
        }
        return false;
    }

    public static function checkEmailExists($email)
    {
        // Соединение с БД
        $db = Db::getConnection();

        // Текст запроса к БД
        $sql = 'SELECT COUNT(*) FROM user WHERE email = :email';

        // Получение результатов. Используется подготовленный запрос
        $result = $db->prepare($sql);
        $result->bindParam(':email', $email, PDO::PARAM_STR);
        $result->execute();

        if ($result->fetchColumn()) {
            return true;
        }
        return false;
    }

    public static function getUserById($id)
    {
        // Соединение с БД
        $db = Db::getConnection();

        // Текст запроса к БД
        $sql = 'SELECT * FROM user WHERE id = :id';

        // Получение и возврат результатов. Используется подготовленный запрос
        $result = $db->prepare($sql);
        $result->bindParam(':id', $id, PDO::PARAM_INT);

        // Указываем, что хотим получить данные в виде массива
        $result->setFetchMode(PDO::FETCH_ASSOC);
        $result->execute();

        return $result->fetch();
    }
    public static function getTreeById($id)
    {
        // Соединение с БД
        $db = Db::getConnection();

        // Текст запроса к БД
        $sql = 'SELECT * FROM tree WHERE id = :id';

        // Получение и возврат результатов. Используется подготовленный запрос
        $result = $db->prepare($sql);
        $result->bindParam(':id', $id, PDO::PARAM_INT);

        // Указываем, что хотим получить данные в виде массива
        $result->setFetchMode(PDO::FETCH_ASSOC);
        $result->execute();

        return $result->fetch();
    }
    public static function getTreeByEmail($email)
    {
        // Соединение с БД
        $db = Db::getConnection();

        // Текст запроса к БД
        $sql = 'SELECT * FROM tree WHERE email = :email';

        // Получение и возврат результатов. Используется подготовленный запрос
        $result = $db->prepare($sql);
        $result->bindParam(':email', $email, PDO::PARAM_STR);

        // Указываем, что хотим получить данные в виде массива
        $result->setFetchMode(PDO::FETCH_ASSOC);
        $result->execute();

        return $result->fetch();
    }

    public static function getProducts(){
        // Соединение с БД
        $db = Db::getConnection();
        // Текст запроса к БД
        $sql = 'SELECT * FROM product';
        // Получение и возврат результатов. Используется подготовленный запрос
        $result = $db->query($sql);

        return $result;
    }
    public static function getUsersFromTree($id){
        // Соединение с БД
        $db = Db::getConnection();
        // Текст запроса к БД
        $sql = "select *from (select * from tree order by parent_id, id) folders_sorted,
        (select @pv := $id) initialisation 
        where find_in_set(parent_id, @pv) > 0 
        and @pv := concat(@pv, ',', id)";
        // Получение и возврат результатов. Используется подготовленный запрос
        $result = $db->query($sql);

        return $result;
    }
	public static function getUsers(){
        // Соединение с БД
        $db = Db::getConnection();
        // Текст запроса к БД
        $sql = "select *from user WHERE id!='0'";
        // Получение и возврат результатов. Используется подготовленный запрос
        $result = $db->query($sql);

        return $result;
    }

    public static function lastID(){
        // Соединение с БД
        $db = Db::getConnection();
        // Текст запроса к БД
        $sql = 'SELECT * FROM tree ORDER BY id DESC LIMIT 1';
        // Получение и возврат результатов. Используется подготовленный запрос
        $result = $db->query($sql);
        $result->setFetchMode(PDO::FETCH_ASSOC);
        return $result->fetch();
    }
	public static function mailTo($img,$mass){
		// картинки
		$path = $_SERVER['DOCUMENT_ROOT'];
		$img_path = $path.'/template/img/kvitancia/'.$img;
		$attach[] = $img_path; 
		// чтобы отображалась картинка и ее не было в аттаче
		// путь к картинке задается через CID: - Content-ID
		// тестовый текст
		$text = '
			<div style="width: 900px; margin: 0 auto;">
				<h1>Заявка на регистрацию </h1>
				<h2>Личные данные</h2>
				<table>
				<tbody>
				<tr><td>Имя</td><td>'.$mass["name"].'</td></tr>
				<tr><td>Фамилия</td><td>'.$mass["surname"].'</td></tr>
				<tr><td>Отчество</td><td>'.$mass["fathername"].'</td></tr>
				<tr><td>Email</td><td>'.$mass["email"].'</td></tr>
				<tr><td>Пароль</td><td>'.$mass["password"].'</td></tr>
				<tr><td>Дата рождения</td><td>'.$mass["data_born"].'</td></tr>
				<tr><td>Пол</td><td>'.$mass["sex"].'</td></tr>
				<tr><td>ИИН</td><td>'.$mass["iin"].'</td></tr>
				<tr><td>Номер карты</td><td>'.$mass["card"].'</td></tr>
				<tr><td>Номер счета</td><td>'.$mass["invoice"].'</td></tr>
				<tr><td>Дата регистраций</td><td>'.$mass["data_reg"].'</td></tr>
				<tr><td>Страна</td><td>'.$mass["country"].'</td></tr>
				<tr><td>Город</td><td>'.$mass["city"].'</td></tr>
				<tr><td>Улица</td><td>'.$mass["street"].'</td></tr>
				<tr><td>Дом</td><td>'.$mass["house"].'</td></tr>
				<tr><td>Квартира</td><td>'.$mass["room"].'</td></tr>
				<tr><td>Закреплен за</td><td>'.$mass["who"].'</td></tr>
				<tr><td>Бизнес продукт</td><td>'.$mass["product"].'</td></tr>
				<tr><td>Подразделение</td><td>'.$mass["team"].'</td></tr>
				</tbody>
				</table>
				<p><img ';
		$text .= 'src="cid:'.$img.'"/>';
		$text .= '</p></div>';

		$from = "info@spaceline.kz";
		//$to = "nurzhanduisenbaev480@mail.ru";
		$to = "info@spaceline.kz";
		$subject = "Регистрация нового пользователя";

		// Заголовки письма === >>>
		$headers = "From: $from\r\n";
		//$headers .= "To: $to\r\n";
		$headers .= "Subject: $subject\r\n";
		$headers .= "Date: " . date("r") . "\r\n";
		$headers .= "X-Mailer: zm php script\r\n";
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "Content-Type: multipart/alternative;\r\n";
		$baseboundary = "------------" . strtoupper(md5(uniqid(rand(), true)));
		$headers .= "  boundary=\"$baseboundary\"\r\n";
		// <<< ====================

		// Тело письма === >>>
		$message  =  "--$baseboundary\r\n";
		$message .= "Content-Type: text/plain;\r\n";
		$message .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
		$message .= "--$baseboundary\r\n";
		$newboundary = "------------" . strtoupper(md5(uniqid(rand(), true)));
		$message .= "Content-Type: multipart/related;\r\n";
		$message .= "  boundary=\"$newboundary\"\r\n\r\n\r\n";
		$message .= "--$newboundary\r\n";
		$message .= "Content-Type: text/html; charset=utf-8\r\n";
		$message .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
		$message .= $text . "\r\n\r\n";
		// <<< ==============

		// прикрепляем файлы ===>>>
		foreach($attach as $filename){
			$mimeType='image/png';
			$fileContent = file_get_contents($filename,true);
			$filename=basename($filename);
			$message.="--$newboundary\r\n";
			$message.="Content-Type: $mimeType;\r\n";
			$message.=" name=\"$filename\"\r\n";
			$message.="Content-Transfer-Encoding: base64\r\n";
			$message.="Content-ID: <$filename>\r\n";
			$message.="Content-Disposition: inline;\r\n";
			$message.=" filename=\"$filename\"\r\n\r\n";
			$message.=chunk_split(base64_encode($fileContent));
		}
		// <<< ====================

		// заканчиваем тело письма, дописываем разделители
		$message.="--$newboundary--\r\n\r\n";
		$message.="--$baseboundary--\r\n";

		// отправка письма
		$result = mail($to, $subject, $message , $headers);
	}

}
