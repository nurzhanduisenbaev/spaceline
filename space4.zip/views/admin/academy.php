<?php include ROOT.'/views/layouts/header_admin.php';?>
<?php include ROOT.'/views/layouts/svg_admin.php';?>
<section class="control-panel-main">
    <div class="left-sidebar">
      <?php include ROOT.'/views/layouts/sidebar_admin.php';?>

    </div>
    <div class="control-panel-content">
        <div class="my-profile-content-top">
            <p>Академия лидеров</p>
            <div class="my-profile-content-log">
				<a href="/admin/teamsreg" class="top_button btn btn-primary">
					Добавить лидера
				</a>
                <a href="/admin/logout">
                    <svg class="control-panel-logout">
                        <use xlink:href="#LogoutIcon"></use>
                    </svg>
                </a>
            </div>
        </div>
		<div class="kabinet-academy-content">
			<div class="kabinet-academy-content-top"></div>
			<div class="kabinet-academy-content-bottom">
				<a href="video_materials.php" class="kabinet-academy-content-bottom-item1">
					<svg class="kabinet-academy-svg"><use xlink:href="#videoPlayerSvg"></use></svg>
					<p>видео материалы</p>
				</a>
				<a href="books.php" class="kabinet-academy-content-bottom-item1">
					<svg class="kabinet-academy-svg"><use xlink:href="#studentSvg"></use></svg>
					<p>литература для чтения</p>
				</a>
				<a href="#" class="kabinet-academy-content-bottom-item"></a>
				<a href="#" class="kabinet-academy-content-bottom-item"></a>
				<a href="#" class="kabinet-academy-content-bottom-item"></a>
				<a href="#" class="kabinet-academy-content-bottom-item"></a>
			</div>
		</div>
		</div>
</section>
<?php include ROOT.'/views/layouts/footer_admin.php';?>