<?php include ROOT.'/views/layouts/header_admin.php';?>
<?php include ROOT.'/views/layouts/svg_admin.php';?>
<section class="control-panel-main">
<?php include ROOT.'/views/layouts/sidebar_admin.php';?>
    <div class="control-panel-content">
        <div class="kabinet-news-main-box">
            <div class="my-profile-content-top">
                <p>Новости ТОО Space Line</p>
				
					<a href="/admin/newsadd" class="btn btn-success">Добавить материал</a>
				
                <a href="/cabinet/logout">
                    <svg class="control-panel-logout">
                        <use xlink:href="#LogoutIcon"></use>
                    </svg>
                </a>
            </div>
            <div class="kabiet-news-items">

				<div class="kabinet-news-item">
					<form method="post">
						<div class="form-group">
							<label>Название</label>
							<input type="text" class="form-control" name="title">
						</div>
						<div class="form-group">
							<label>Описание</label>
							<textarea class="form-control" rows="5" name="description">
							</textarea>
						</div>
						<div class="form-group">
						<input type="submit" class="btn btn-success" name="add" value="Добавить">
						</div>
					</form>
				</div>

            </div>
        </div>

    </div>
</section>

</body>
</html>
