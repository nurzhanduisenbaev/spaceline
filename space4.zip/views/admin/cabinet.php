<?php include ROOT.'/views/layouts/header_admin.php';?>
<?php include ROOT.'/views/layouts/svg_admin.php';?>
<section class="control-panel-main">
    
        <?php include ROOT.'/views/layouts/sidebar_admin.php';?>
        <div class="control-panel-content">
            <div class="control-panel-content-top">
                <p>панель управления</p>
                <a href="/admin/teamsreg" class="top_button btn btn-primary">
					Добавить лидера
				</a>
                <a href="/admin/logout">
                    <svg class="control-panel-logout">
                        <use xlink:href="#LogoutIcon"></use>
                    </svg>
                </a>
            </div> <!-- /.control-panel-content-top -->
            <div class="control-panel-money-statistics">
				<div class="container adminCab" style="margin-bottom: 30px;">
					<div class="row">
						<div class="col-md-4">
							<div class="oborot" style="background:#e7e7e7;color:#000;">
							<h5>Оборот компаний</h5>
								<?php 
								$all = 0;
								while($r2 = $allInc->fetch(PDO::FETCH_ASSOC)){
									$all += ($r2['total']*100)/16.07;
								}
								?>
							<p><?php echo $all.' тг';?></p>
							</div>
						</div>
						<div class="col-md-4">
							<div class="dayoborot" style="background:#777;">
							<h5>Дневной оборот компаний</h5>
								<?php 
								$day = 0;
								while($r = $dayInc->fetch(PDO::FETCH_ASSOC)){
									$day += ($r['total']*100)/16.07;
								}
								?>
							<p><?php echo $day.' тг';?></p>
							</div>
						</div>
						<div class="col-md-4">
							<div class="kolpart" style="background:#505050;">
							<h5>Количество партнеров</h5>
								<?php 
								$c = 0;
								while($c = $partnerCount->fetch(PDO::FETCH_ASSOC)){
									$c = $c['COUNT(id)'];
									echo "<p>".$c."</p>";
								}
								?>
							
							</div>
						</div>
					</div>
				</div>
				<div class="container adminCab">
					<div class="row">
						<div class="col-md-4">
							<div class="kollider" style="background:#00A1E4;">
							<h5>Количество лидеров</h5>
								<?php
								
								$l = 0;
								while($l = $liderCount->fetch(PDO::FETCH_ASSOC)){
									$l = $l['COUNT(id)'];
									echo "<p>".$l."</p>";
								}
								?>
								
							
							</div>
						</div>
						<div class="col-md-4">
							<div class="kollider" style="background:#00A1E4;">
							<h5>Количество аккаунтов</h5>
								<?php
								
								$l2 = 0;
								while($l2 = $account->fetch(PDO::FETCH_ASSOC)){
									$l2 = $l2['COUNT(id)'];
									echo "<p>".$l2."</p>";
								}
								?>
								
							
							</div>
						</div>
						<div class="col-md-4">
							
						</div>
						
					</div>
				</div>
				<div class="container" id="incomes" style="margin-top:30px;">
					<div class="row">
						<div class="col-md-12">
							<table class="table table-stripped table-bordered">
								<thead>
									<tr>
										<th>#</th>
										<th>Ф.И.О</th>
										<th>Email</th>
										<th>Имя дохода</th>
										<th>Дата поступления</th>
										<th>Сумма</th>
										
									</tr>
								</thead>
								<tbody>
								<?php $index=0;?>
									<?php foreach($income as $inc):?>
									<?php $index++;?>
									<tr>
										<td><?php echo $index;?></td>
										<td><?php echo $inc['fio'];?></td>
										<td><?php echo $inc['email'];?></td>
										<td><?php echo $inc['name'];?></td>
										<td><?php echo $inc['date'];?></td>
										<td><?php echo $inc['total'];?></td>
									</tr>
									<?php endforeach;?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
				<div class="container">
				<div class="row">
					<div class="col-md-12">
					<?php echo $pagination->get(); ?>
					</div>
				</div>
			</div>
				
			</div>
            
            
            
    </div>
        </div>
    </section>
<?php include ROOT.'/views/layouts/footer_admin.php';?>
