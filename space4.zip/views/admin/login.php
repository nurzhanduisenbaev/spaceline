<?php include ROOT . '/views/layouts/header_login.php'; ?>
<section>
    <div id="loginform" style="margin-top:150px;">
        <div>
            <?php if (isset($errors) && is_array($errors)): ?>
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li> - <?php echo $error; ?></li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>
        <div class="container">
			<div class="row justify-content-center">
				<h4>Авторизация</h4>
			</div>
            <div class="row justify-content-center">
                
                <form method="post" action="/admin/login">                    
                    <div class="form-group">
                      
                      <input type="email" name="email" class="form-control" id="exampleInputEmail1" placeholder="Введите Email">
                    </div>
                    <div class="form-group">
                      
                      <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Пароль">
                    </div>
                    
                    <button type="submit" name="submit" class="btn btn-primary">Войти</button>
                </form>
            </div>
        </div> 
    </div>   
</section>

<?php include ROOT . '/views/layouts/footer_login.php'; ?>