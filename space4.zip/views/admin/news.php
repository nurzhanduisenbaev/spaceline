<?php include ROOT.'/views/layouts/header_admin.php';?>
<?php include ROOT.'/views/layouts/svg_admin.php';?>
<section class="control-panel-main">
<?php include ROOT.'/views/layouts/sidebar_admin.php';?>
    <div class="control-panel-content">
        <div class="kabinet-news-main-box">
            <div class="my-profile-content-top">
                <p>Новости ТОО Space Line</p>
				
					<a href="/admin/newsadd" class="btn btn-success">Добавить новость</a>
				
                <a href="/cabinet/logout">
                    <svg class="control-panel-logout">
                        <use xlink:href="#LogoutIcon"></use>
                    </svg>
                </a>
            </div>
            <div class="kabiet-news-items">

				<div class="kabinet-news-item">
					<div class="container">
						
						<?php while($row = $result->fetch(PDO::FETCH_ASSOC)):?>
						<div class="row" style="margin-bottom:20px;background: white;padding: 10px;">
							<div class="col-md-12">
								<img src="images_posts/post_image/<?php echo $row['image'];?>">
								<h3><?php echo $row['title'];?></h3>
								<div class="news-date-btn">
									<p class="article-date">Дата: <?php echo $row['date'];?></p>
									<a href="/admin/newsview" class="news-more">Подробнее</a>
								</div>
							</div>
						</div>
						<?php endwhile;?>
							
					</div>
				</div>

            </div>
        </div>

    </div>
</section>

</body>
</html>
