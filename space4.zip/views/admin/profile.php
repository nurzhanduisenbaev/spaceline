<?php include ROOT.'/views/layouts/header_admin.php';?>
<?php include ROOT.'/views/layouts/svg_admin.php';?>
<section class="control-panel-main">

        <?php include ROOT.'/views/layouts/sidebar_admin.php';?>
        <div class="my-profile-main-box">
            <div class="my-profile-content-top">
                <p>Мой профиль</p>
                <a href="/admin/logout">
                    <svg class="control-panel-logout">
                        <use xlink:href="#LogoutIcon"></use>
                    </svg>
                </a>
            </div>
            <div class="my-profile-main-info">
                <div class="my-profile-main-info-left">
                    <div class="my-profile-main-info-left-top">
                        <div class="my-profile-main-info-left-top-first">
                            <div class="my-profile-main-info-photo">
                                <img src="includes/img_icons/image">
                            </div>
                            <div class="my-profile-main-info-name">
                                <h4><?php echo $user['name'].' '.$user['surname'];?></h4>
                                <p><?php echo $user['role'];?></p>
                            </div>
                        </div>
                        <div class="my-profile-main-info-left-top-second">
                            <a href="/profile/edit/<?php echo $userId;?>" class="my-profile-main-info-left-top-second-left">
                                <svg class="svg-edit"><use xlink:href="#myProfileEdit"></use></svg>
                                <p>Редактировать</p>
                            </a>
                            <a href="#" class="my-profile-main-info-left-top-second-right">
                                <svg class="svg-edit"><use xlink:href="#myProfilePicture"></use></svg>
                                <p>Сменить фото</p>
                            </a>
                        </div>
                    </div>
                    <div class="my-profile-main-info-left-bottom">
                        <p>Моя реферальная ссылка</p>
                        <div class="my-profile-main-info-left-bottom-linkblock">
                            <div class="my-profile-main-info-link"><a id="copier" href="#">/referal-link.php?id=<?php echo $user['id'];?></a></div>
                            <div onclick="fnk()" id="click" class="my-profile-main-info-copylink">
                                <img src="img/copy.png" alt="">
                            </div>
                        </div>
                        <script>
                        function fnk(){
                              alert("Ваша реферальная ссылка скопирована в буфер обмена!");
                        	    var $temp = $("<input>");
                        	    $("body").append($temp);
                        	    $temp.val($('#copier').text()).select();
                        	    document.execCommand("copy");
                        	    $temp.remove();

                        }

                        </script>
                    </div>
                </div> <!-- /.my-profile-main-info-left -->
                <div class="my-profile-main-info-right">
                    <h4>Адрес</h4>
                    <div class="my-profile-main-info-right-address">
                        <div class="main-info-address-item-left">
                            <svg class="svg-address"><use xlink:href="#myProfileFlag"></use></svg>
                            <p>Страна</p>
                        </div>
                        <div class="main-info-address-item-right"><?php echo $user['country'];?></div>
                        <div class="main-info-address-item-left">
                            <svg class="svg-address"><use xlink:href="#myProfilePlaceHolder"></use></svg>
                            <p>Город</p>
                        </div>
                        <div class="main-info-address-item-right">г. <?php echo $user['city'];?></div>
                        <div class="main-info-address-item-left">
                            <svg class="svg-address"><use xlink:href="#myProfileStreet"></use></svg>
                            <p>Улица</p>
                        </div>
                        <div class="main-info-address-item-right"><?php echo $user['street'];?></div>
                        <div class="main-info-address-item-left">
                            <svg class="svg-address"><use xlink:href="#myProfileHotel"></use></svg>
                            <p>Здание</p>
                        </div>
                        <div class="main-info-address-item-right"><?php echo $user['house'];?></div>
                        <div class="main-info-address-item-left">
                            <svg class="svg-address"><use xlink:href="#myProfileRoom"></use></svg>
                            <p>Квартира</p>
                        </div>
                        <div class="main-info-address-item-right"><?php echo $user['room'];?></div>
                    </div> <!-- /.my-profile-main-info-right-address -->
                    <div class="main-info-address-contacts">
                        <h4>Контакты</h4>
                        <div class="main-info-contacts-box">
                            <div class="main-info-contacts-box-left">
                                <a href="tel:mobile" class="main-info-contacts-phone">Тел: <?php echo $user['mobile'];?></a>
                                <a href="mailto:email>" class="main-info-contacts-phone">Email:  <?php echo $user['email'];?></a>
                            </div>
                            <div class="main-info-contacts-box-right">
                                <div class="main-info-contacts-box-right-block1">
                                    <svg class="svg-contacts"><use xlink:href="#myProfilePackage"></use></svg>
                                    <p><?php echo (isset($user['product']))?$user['product']:'Нет продукта';?></p>
                                </div>
                                <div class="main-info-contacts-box-right-block2">
                                    <svg class="svg-contacts"><use xlink:href="#myProfileInvitation"></use></svg>
                                    <p> Space line</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> <!-- /.my-profile-main-info-right -->
            </div> <!-- /.my-profile-main-info -->
        </div> <!-- /.my-profile-main-box -->
    </section>
<?php include ROOT.'/views/layouts/footer_admin.php';?>
