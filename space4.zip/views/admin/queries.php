<?php include ROOT.'/views/layouts/header_admin.php';?>
<?php include ROOT.'/views/layouts/svg_admin.php';?>
<section class="control-panel-main">

    <?php include ROOT.'/views/layouts/sidebar_admin.php';?>
    <div class="control-panel-content">
        <div class="control-panel-content-top">
            <p>Выплаты</p>
            <a href="/admin/teamsreg" class="top_button btn btn-primary">
                Добавить лидера
            </a>
            <a href="/admin/logout">
                <svg class="control-panel-logout">
                    <use xlink:href="#LogoutIcon"></use>
                </svg>
            </a>
        </div> <!-- /.control-panel-content-top -->
        <div class="control-panel-money-statistics">
			<table class="table table-stripped table-bordered">
				<thead>
					<tr>
						<th>#</th>
						<th>Ф.И.О</th>
						<th>Email</th>
						<th>Дата</th>
						<th>Сумма</th>
						
						<th>Подтвердить</th>
					</tr>
				</thead>
				<tbody>
					<?php //if($result2):?>
					<?php $index=0;?>
					<?php while($row = $result2->fetch(PDO::FETCH_ASSOC)):?>
					<?php $index++;?>
					<?php if($row['id'] !=1):?>
					<tr>
						<td><?php echo $index;?></td>
						<td><?php echo $row['name'].' '.$row['surname'];?></td>
						<td><?php echo $row['email'];?></td>
						<td><?php echo $row['data_reg'];?></td>
						<td><?php echo $row['product'];?></td>
						
						<td>
							<form method="post">
								<input type="hidden" name="id" value="<?php echo $row['id'];?>">
								<input type="hidden" name="email" value="<?php echo $row['email'];?>">
								<input type="hidden" name="password" value="<?php echo $row['password'];?>">
								<input type="hidden" name="parent_id" value="<?php echo $row['parent_id'];?>">
								<input type="hidden" name="name" value="<?php echo $row['name'];?>">
								<input type="hidden" name="surname" value="<?php echo $row['surname'];?>">
								<input type="hidden" name="user_id" value="<?php echo $row['user_id'];?>">
								<input type="hidden" name="team" value="<?php echo $row['team'];?>">
								<input type="hidden" name="side" value="<?php echo $row['side'];?>">
								<input type="hidden" name="product" value="<?php echo $row['product'];?>">
								<input type="hidden" name="group_id" value="<?php echo $row['group_id'];?>">
								<input type="submit" class="btn btn-success" value="Принять" name="prinyat">
								<input type="submit" class="btn btn-danger" value="Отклонить" name="otklonit">
							</form>
							
						</td>
					</tr>
					<?php endif;?>
					<?php endwhile;?>
					
					
				</tbody>
			</table>
        </div> <!-- /.control-panel-money-statistics -->

    </div>
</section>
<style>
	div.node{
		width: 120px;
	}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<?php include ROOT.'/views/layouts/footer_admin.php';?>
<?php if($ok){header("Location: /admin/queries");}?>