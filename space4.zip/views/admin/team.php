<?php include ROOT.'/views/layouts/header_admin.php';?>
<?php include ROOT.'/views/layouts/svg_admin.php';?>
<section class="control-panel-main">

    <?php include ROOT.'/views/layouts/sidebar_admin.php';?>
    <div class="control-panel-content">
        <div class="control-panel-content-top">
            <p>панель управления</p>
            <a href="/admin/teamsreg" class="top_button btn btn-primary">
                Добавить лидера
            </a>
            <a href="/admin/logout">
                <svg class="control-panel-logout">
                    <use xlink:href="#LogoutIcon"></use>
                </svg>
            </a>
        </div> <!-- /.control-panel-content-top -->
        <div class="control-panel-money-statistics">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
					<table class="table table-stripped table-bordered">
						<thead>
							<tr>
								<th>#</th>
								<th>Ф.И.О</th>
								<th>Email</th>
								<th>Пакет</th>

							</tr>
						</thead>
						<tbody>
							<?php $index=0;?>
							<?php foreach($users as $us):?>
							<?php $index++;?>
							<tr>
								<td><?php echo $index;?></td>
								<td><?php echo $us['name'].' '.$us['surname'];?></td>
								<td><?php echo $us['email'];?></td>
								<td><?php echo $us['product'];?></td>
							</tr>
							<?php endforeach;?>
						</tbody>
					</table>
					</div>
				</div>
			</div>
			<div class="container">
				<div class="row">
					<div class="col-md-12">
					<?php echo $pagination->get(); ?>
					</div>
				</div>
			</div>
        </div> <!-- /.control-panel-money-statistics -->

    </div>
</section>
<style>
	div.node{
		width: 120px;
	}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<?php include ROOT.'/views/layouts/footer_admin.php';?>
