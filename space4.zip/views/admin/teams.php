<?php include ROOT.'/views/layouts/header_admin.php';?>
<?php include ROOT.'/views/layouts/svg_admin.php';?>
<section class="control-panel-main">

    <?php include ROOT.'/views/layouts/sidebar_admin.php';?>
    <div class="control-panel-content">
        <div class="control-panel-content-top">
            <p>Подразделение</p>
            <a href="/admin/teamsreg" class="top_button btn btn-primary">
                Добавить лидера
            </a>
            <a href="/admin/logout">
                <svg class="control-panel-logout">
                    <use xlink:href="#LogoutIcon"></use>
                </svg>
            </a>
        </div> <!-- /.control-panel-content-top -->
        <div class="control-panel-money-statistics">
			<table class="table table-stripped table-bordered">
				<thead>
					<tr>
						<th>#</th>
						<th>Ф.И.О</th>
						<th>Подразделение</th>
						
					</tr>
				</thead>
				<tbody>
					<?php $index=0;?>
					<?php while($row=$result->fetch(PDO::FETCH_ASSOC)):?>
					<?php $index++;?>
					<tr>
						<td><?php echo $index;?></td>
						<td><?php echo $row['name'].' '.$row['surname'];?></td>
						<td><?php echo $row['team'];?></td>
					</tr>
					<?php endwhile;?>
				</tbody>
			</table>
        </div> <!-- /.control-panel-money-statistics -->

    </div>
</section>
<style>
	div.node{
		width: 120px;
	}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<?php include ROOT.'/views/layouts/footer_admin.php';?>
