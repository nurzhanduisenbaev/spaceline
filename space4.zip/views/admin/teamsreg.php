<?php include ROOT.'/views/layouts/header_admin.php';?>
<?php include ROOT.'/views/layouts/svg_admin.php';?>
<section class="control-panel-main">

    <?php include ROOT.'/views/layouts/sidebar_admin.php';?>
    <div class="control-panel-content">
        <div class="control-panel-content-top">
            <p>Подразделение</p>
            
            <a href="/admin/logout">
                <svg class="control-panel-logout">
                    <use xlink:href="#LogoutIcon"></use>
                </svg>
            </a>
        </div> <!-- /.control-panel-content-top -->
        <div class="control-panel-money-statistics">
			<?php
                    //if(isset($errors) && is_array($errors)){
                       // foreach ($errors as $error){
                            //echo '<span style="color:red;">';
                            //print_r ($error);
                           // echo '</span>';
                       // }
                   // }
                    
                    //if($trues){
                       // echo '<script>alert("Регистрация прошла успешно!!!");</script>';
                        //echo $trues;
                   // }
                ?>
                <div id="registerForm">
                    <form method="post" enctype="multipart/form-data">
                        <fieldset>
                            <legend>Учетная запись</legend>
                            <div class="form-group">
                                <label>Роль</label>
                                <input type="text" name="role" class="role form-control" value="Лидер" readonly>
                            </div>
                            <div class="form-group">
                                <label for="email">Email<span style="color:red;">*</span></label>
                                <input type="text" name="email" class="email form-control" id="email" required>
                            </div>
                            <div class="form-group">
                                <label for="password">Пароль<span style="color:red;">*</span></label>
                                <input type="text" name="password" class="password form-control" id="password" required>
                            </div>
                            <div class="form-group">
                                <label for="surname">Фамилия<span style="color:red;">*</span></label>
                                <input type="text" name="surname" class="surname form-control" id="surname" required>
                            </div>
                            <div class="form-group">
                                <label for="name">Имя<span style="color:red;">*</span></label>
                                <input type="text" name="name" class="name form-control" id="name" required>
                            </div>
                            <div class="form-group">
                                <label for="lastname">Отчество<span style="color:red;">*</span></label>
                                <input type="text" name="lastname" class="lastname form-control" id="lastname">
                            </div>
                            <div class="form-group">
                                <label for="data_born">Дата рождения<span style="color:red;">*</span></label>
                                <div id="datatimepicker1">
                                    <input type="text" name="data_born" class="data_born form-control" id="data_born" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Пол<span style="color:red;">*</span></label>
                                <div id="sexy">
                                
                                    <div class="sexy-item">
                                        <label for="male">Мужчина</label>
                                        <input type="radio" name="sex" class="sex form-control" value="Мужщина" id="male">
                                    </div>
                                    <div class="sexy-item">
                                        <label for="female">Женщина</label>
                                        <input type="radio" name="sex" class="sex form-control" value="Женщина" id="female">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="iin">ИИН<span style="color:red;">*</span></label>
                                <input type="text" name="iin" class="iin form-control" id="iin" required>
                            </div>
                            <div class="form-group">
                                <label for="card">Номер карты<span style="color:red;">*</span></label>
                                <input type="text" name="card" class="card form-control" id="card" required>
                            </div>
                            <div class="form-group">
                                <label for="invoice">Номер счета<span style="color:red;">*</span></label>
                                <input type="text" name="invoice" class="invoice form-control" id="invoice" required>
                            </div>
                            <div class="form-group">
                                <label for="data_reg">Дата регистраций<span style="color:red;">*</span></label>
                                <input type="text" name="data_reg" class="data_reg form-control" id="data_reg" readonly value="<?php echo date('Y-m-d');?>" required>
                            </div>
                        </fieldset>
                        <fieldset>
                            <legend>Адрес</legend>
                            <div class="form-group">
                                <label for="country">Страна<span style="color:red;">*</span></label>
                                <input type="text" name="country" class="country form-control" id="country" required>
                            </div>
                            <div class="form-group">
                                <label for="city">Город<span style="color:red;">*</span></label>
                                <input type="text" name="city" class="city form-control" id="city" required>
                            </div>
                            <div class="form-group">
                                <label for="street">Улица<span style="color:red;">*</span></label>
                                <input type="text" name="street" class="street form-control" id="street" required>
                            </div>
                            <div class="form-group">
                                <label for="house">Дом<span style="color:red;">*</span></label>
                                <input type="text" name="house" class="house form-control" id="house" required>
                            </div>
                            <div class="form-group">
                                <label for="room">Квартира</label>
                                <input type="text" name="room" class="room form-control" id="room">
                            </div>
                        </fieldset>
                        <fieldset>
                            <legend>Регистрационные сведения</legend>
                   			<div class="data-group">
                                <label for="team">Подразделение</label>
                                <input type="text" name="team" class="team form-control" id="team" required>
                            </div>
                        </fieldset>
                        
                        <fieldset>
                            <div class="data-group">
                                <input type="submit" name="register" class="register" value="Добавить">
                            </div>
                        </fieldset>
                        
                    </form>
                </div>
        </div> <!-- /.control-panel-money-statistics -->

    </div>
</section>
<style>
	div.node{
		width: 120px;
	}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<?php include ROOT.'/views/layouts/footer_admin.php';?>
