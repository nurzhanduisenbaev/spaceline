<?php include ROOT.'/views/layouts/header.php';?>
<?php include ROOT.'/views/layouts/svg.php';?>
<section class="control-panel-main">
    
        <?php include ROOT.'/views/layouts/sidebar.php';?>
        <div class="control-panel-content">
            <div class="control-panel-content-top">
                <p>панель управления</p>
                <a href="/user/register" class="btn btn-primary top_button">
                    Добавить партнера
                </a>
                <a href="/cabinet/logout">
                    <svg class="control-panel-logout">
                        <use xlink:href="#LogoutIcon"></use>
                    </svg>
                </a>
            </div> <!-- /.control-panel-content-top -->
            <div class="control-panel-money-statistics">
			<div id='uvedomlenie' style="display:none;">
					Вы успешно подали анкету на регистрацию нового пользователя в  партнерской системе Spaceline<br>
					Ответ от администрации сайта пользователь получит на электронный адрес 
				</div>
			<div class="container" style="margin-bottom: 40px;">
				<div class="row">
					<div class="col-md-3" style="display:flex;
											background: #e7e7e7;
											border-radius: 5px;
											box-shadow: 0px 1px 5px #3333338c;
											color: #333;">
							<img src="/template/img/Bileti.png">
							<div style="margin-top: 20px;"><h5>МОИ БИЛЕТЫ</h5>
						<p>
						<?php echo $user['bilet'];?>
						</p>
						</div>
					</div>
					<?php if($user['role'] == 'Лидер'):?>
					<div class="col-md-3">
						<div class="sutka">
							<h5>ДНЕВНОЙ ОБОРОТ КОМПАНИЙ</h5>
							
							<p><?php echo $day;?></p>
						</div>
					</div>
			
					
					<?php endif;?>
					<div class="col-md-3">
						<div class="packet_count">
							<h5>КОЛИЧЕСТВО ПРОДАННЫХ АККАУНТ</h5>
							<p><?php echo $account;?></p>
						</div>
					</div>
					<div class="col-md-3">
						<div class="all_zarabotok">
							<h5>ОБОРОТ КОМАНДЫ</h5>
							<p><?php echo $teampack;?></p>
						</div>
					</div>
				</div>
			</div>
            <div class="money-statistics-item" style="position: relative;">
                <div class="money-statistics-item-top-first">
                    <div class="money-statistics-item-top-left">
                        <svg class="money-statistics-icon">
                            <use xlink:href="#mainMoney1"></use>
                        </svg>
                    </div>
                    <div class="money-statistics-item-top-right">
                        <p class="money-statistics-text">БАЛАНС</p>
                        <p class="money-statistics-text-money">
						<?php echo $all;?>
						</p>
                    </div>
                </div>
                <div class="money-statistics-item-bottom">
                    <button class="btn btn-primary take1">Вывод средств</button>
                </div>
				<div id="take1" style="display:none;
						position:absolute;z-index:1;right: 0px;
						top: 150px;
						background: #fff;
						padding: 10px;
						border: 1px solid rgba(0,0,0,0.5);">
					<form method="post" id="form1" enctype="multipart/form-data">
						<div class="form-group">
							<input type="hidden" name="tname" class="form-control" value="<?php echo $user['name'];?>">
							<input type="hidden" name="tsurname" class="form-control" value="<?php echo $user['surname'];?>">
							<input type="hidden" name="tuser_id" class="form-control" value="<?php echo $user['id'];?>">
							<input type="hidden" name="temail" class="form-control" value="<?php echo $user['email'];?>">
							<input type="hidden" name="tinvoice" class="form-control" value="<?php echo $user['invoice'];?>">
							<input type="hidden" name="tinn" class="form-control" value="<?php echo $user['iin'];?>">
							<input type="hidden" name="tcard" class="form-control" value="<?php echo $user['card'];?>">
							<label for="n">Укажите сумму(сумма не должна быть меньше 12000 тг)</label>							
							<input type="text" name="summa2" id="n2" class="form-control">
						</div>
						<div class="form-group">
							<input type="submit" class="btn btn-primary" name="summa-request2" id="otpravit2" value="Отправить запрос">
						</div>

					</form>
				</div>
            </div>
            <div class="money-statistics-item" style="position:relative;">
                <div class="money-statistics-item-top-second">
                    <div class="money-statistics-item-top-left">
                        <svg class="money-statistics-icon">
                            <use xlink:href="#mainHand"></use>
                        </svg>
                    </div>
                    <div class="money-statistics-item-top-right">
                        <p class="money-statistics-text">ПАССИВНЫЙ ДОХОД</p>
						<?php 
							$pass = 0;
						
							$r3 = $income8->fetch(PDO::FETCH_ASSOC);
							//echo $r3;
							//print_r($r3);
							$pass = $r3['total'];
						?>
                        <p class="money-statistics-text-money">
							<?php echo round($pass, 2).' тг';?>
						</p>
                    </div>
                </div>
                <div class="money-statistics-item-bottom">
                    <button class="btn btn-primary take2">Вывод средств</button>
                </div>
				<div id="take2" style="display:none;
						position:absolute;z-index:1;right: 0px;
						top: 150px;
						background: #fff;
						padding: 10px;
						border: 1px solid rgba(0,0,0,0.5);">
					<form method="post" id=form2"" enctype="multipart/form-data">
						<div class="form-group">
							<input type="hidden" name="tname" class="form-control" value="<?php echo $user['name'];?>">
							<input type="hidden" name="tsurname" class="form-control" value="<?php echo $user['surname'];?>">
							<input type="hidden" name="tuser_id" class="form-control" value="<?php echo $user['id'];?>">
							<input type="hidden" name="temail" class="form-control" value="<?php echo $user['email'];?>">
							<input type="hidden" name="tinvoice" class="form-control" value="<?php echo $user['invoice'];?>">
							<input type="hidden" name="tinn" class="form-control" value="<?php echo $user['iin'];?>">
							<input type="hidden" name="tcard" class="form-control" value="<?php echo $user['card'];?>">
							<label for="n">Укажите сумму(сумма не должна быть меньше 12000 тг)</label>
							<input type="text" name="summa" id="n" class="form-control">
						</div>

						<div class="form-group">
							<input type="submit" class="btn btn-primary" name="summa-request" id="otpravit" value="Отправить запрос">
						</div>
					</form>
				</div>
            </div>
            <div class="money-statistics-item">
                <div class="money-statistics-item-top-third">
                    <div class="money-statistics-item-top-left">
                        <svg class="money-statistics-icon">
                            <use xlink:href="#mainMoney2"></use>
                        </svg>
                    </div>
                    <div class="money-statistics-item-top-right">
                        <p class="money-statistics-text">ДОХОД ЗА ВЕСЬ ПЕРИОД</p>
                        <p class="money-statistics-text-money">
							<?php echo $all2;?>
						</p>
                    </div>
                </div>
            </div>
            <div class="money-statistics-item">
                <div class="money-statistics-item-top-fourth">
                    <div class="money-statistics-item-top-left">
                        <svg class="money-statistics-icon">
                            <use xlink:href="#mainProfits"></use>
                        </svg>
                    </div>
                    <div class="money-statistics-item-top-right">
                        <p class="money-statistics-text" style="color:black;">ВСЕГО ПАССИВНОГО ДОХОДА</p>
						<?php
						$passives = 0;
						while($r4 = $income9->fetch(PDO::FETCH_ASSOC)){
							$passives+=$r4['total'];
						}
						?>
                        <p class="money-statistics-text-money" style="color:black;">
							<?php echo round($passives, 2).' тг';?>
						</p>
                    </div>
                </div>
            </div>
        </div> <!-- /.control-panel-money-statistics -->
        <div class="control-panel-my-team-title"><p>МОЯ КОМАНДА</p></div>
        <div class="control-panel-my-team">
            <div class="money-statistics-item">
                <div class="money-statistics-item-top-fifth">
                    <div class="money-statistics-item-top-left">
                        <svg class="money-statistics-icon">
                            <use xlink:href="#presentationYouth"></use>
                        </svg>
                    </div>
                    <div class="money-statistics-item-top-right">
                        <p class="money-statistics-text">Моя команда</p>
                        <p class="money-statistics-text-money">
							<?php echo $countArr;?>
						</p>
                    </div>
                </div>
                <div class="money-statistics-item-bottom">
                    <a href="add.php">Добавить нового</a>
                </div>
            </div>
            <div class="money-statistics-item">
                <div class="money-statistics-item-top-sixth">
                    <div class="money-statistics-item-top-left">
                        <svg class="money-statistics-icon">
                            <use xlink:href="#navUser"></use>
                        </svg>
                    </div>
                    <div class="money-statistics-item-top-right">
                        <p class="money-statistics-text">НОВЫХ ЗА МЕСЯЦ</p>
                        <p class="money-statistics-text-money">
							<?php echo count($c);?>
						</p>
                    </div>
                </div>
            </div>
        </div> <!-- /.control-panel-my-team -->
    </div>
        </div>
    </section>
<?php include ROOT.'/views/layouts/footer.php';?>
<script>
$(function () {
	$('#otpravit2').bind('click', function (event) {
		// using this page stop being refreshing 
		$('#take1').hide();
		event.preventDefault();
		$.ajax({
			type: 'POST',
			url: '/cabinet/take',
			data: $('#form1').serialize(),
			success: function (html) {
				$('#uvedomlenie').css({
					'border': '1px solid black',
					'z-index':'1',
					'position': 'fixed',
					'top': '5px',
					'padding': '10px',
					'display': 'block',
					'background':'#393186',
					'color':'#fff',
					'transition':'all 0.6',
				});
				$('#uvedomlenie').click(function(){
					$(this).hide();
				});
			}
		});
	});
	$('#otpravit').bind('click', function (event) {
		// using this page stop being refreshing 
		$('#take2').hide();
		event.preventDefault();
		$.ajax({
			type: 'POST',
			url: '/cabinet/take',
			data: $('#form2').serialize(),
			success: function (html) {
				$('#uvedomlenie').css({
					'border': '1px solid black',
					'z-index':'1',
					'position': 'fixed',
					'top': '5px',
					'padding': '10px',
					'display': 'block',
					'background':'#393186',
					'color':'#fff',
					'transition':'all 0.6',
				});
				$('#uvedomlenie').click(function(){
					$(this).hide();
				});
			}
		});
	});
})

</script>
<?php if($ok):?>
<script>
	$('#uvedomlenie').css({
		'border': '1px solid black',
		'position': 'fixed',
		'top': '5px',
		'padding': '10px',
		'display': 'block',
		'background':'#393186',
		'color':'#fff',
		'transition':'all 0.6',
	});
	$('#uvedomlenie').click(function(){
		$(this).hide();
	});

</script>
<?php endif;?>