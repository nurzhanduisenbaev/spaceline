<?php include ROOT.'/views/layouts/header.php';?>
<?php include ROOT.'/views/layouts/svg.php';?>
<section class="control-panel-main">

    <?php include ROOT.'/views/layouts/sidebar.php';?>
    <div class="control-panel-content">
        <div class="control-panel-content-top">
            <p>Регистрация Партнеров</p>
            <a href="/cabinet/logout">
                <svg class="control-panel-logout">
                    <use xlink:href="#LogoutIcon"></use>
                </svg>
            </a>
        </div> <!-- /.control-panel-content-top -->
        <div class="control-panel-money-statistics">
            
			<button id="reload" class="btn btn-primary" style="margin-left: 15px; margin-bottom: 10px;">Обновить</button>
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <table class="table table-bordered table-stripped">
                            <thead>
                            <tr>
                                <th>№</th>
                                <th>Партнер</th>
                                <th>Имя дохода</th>
                                <th>Дата поступления/выплаты</th>
                                <th>Сумма</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if($income):?>

                                <?php $index = 0;?>
								<?php foreach($income as $inc):?>
								<?php $index++;?>
								
                                    <tr>
                                        <td><?php echo $index;?></td>
                                        <td><?php echo $inc['fio'];?></td>
                                        <td><?php echo $inc['name'];?></td>
                                        <td><?php echo $inc['date'];?></td>
                                        <td><?php echo $inc['total'];?></td>
                                    </tr>
								
                                <?php endforeach;?>

                            <?php else:?>
                            <tr><td colspan="5">У вас еще нету дохода</td></tr>
                            <?php endif;?>
                            </tbody>
                            <tfooter></tfooter>
                        </table>
						
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <?php echo $pagination->get(); ?>
                    </div>
                </div>
            </div>

        </div> <!-- /.control-panel-money-statistics -->

    </div>
</section>
<?php include ROOT.'/views/layouts/footer.php';?>
<script>
$('#reload').click(function(){
location.reload();
});
</script>