<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<script src="https://d3js.org/d3.v5.min.js"></script>
<script src="/template/js/script.js"></script>
<script>
	var t = 0;	
	$('.take1').click(function(){
		if(t == 0){
			$('#take1').show();
			t=1;
		}else if(t==1){
			$('#take1').hide();
			t=0;
		}
	});
	var t2 = 0;	
	$('.take2').click(function(){
		if(t2 == 0){
			$('#take2').show();
			t2=1;
		}else if(t2==1){
			$('#take2').hide();
			t2=0;
		}
	});

</script>
</body>
</html>