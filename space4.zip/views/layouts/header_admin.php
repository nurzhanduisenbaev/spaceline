<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="/resources/demos/style.css">
 	<link rel="stylesheet" href="/template/css/jquery.orgchart.css">
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="/template/css/style.css">
    <title>Space Line company - панель управления</title>
    <style>
        rect {
           fill: white;
           stroke: silver;
           width: 80px;
           height: 30px;
           stroke-width: 1;
           stroke: rgb(0, 0, 0);
        }
        path.pathes {
           fill: none;
           stroke: rebeccapurple;
           stroke-width: 1px;
        }
        text {
           dominant-baseline: middle;
           text-anchor: middle;
           font-size: 10px;
        }

        .mytree g text{
            border: 1px solid black;
        }
   </style>
</head>
<body>