<div class="left-sidebar">
    <a href="#" class="left-sidebar-logo">
        <img src="/template/img/logo.png" alt="Space Line Company">
    </a>
    <div class="left-sidebar-user">
        <div class="left-sidebar-user-photo">
            <img src="/template/img/control-panel-page/<?php echo $user['image'];?>">
        </div>
        <div class="left-sidebar-user-name">
            <a href="/admin/profile/<?php echo $userId;?>">
                <?php
                    
                    $surname = $user['surname'];
                    $surname = mb_substr($surname, 0, 1);
                    echo $user['name'].' '.$surname.'.';
                ?>
            </a>
            <p><?php echo $user['role'];?></p>
			
        </div>
    </div>
    <nav class="sidebar-nav">
        <a href="/admin/cabinet/page-1" class="sidebar-nav-item">
            <svg class="sidebar-nav-item-icon">
                <use xlink:href="#mainProfits"></use>
            </svg>
            <p>панель управления</p>
        </a>
        <a href="/admin/profile/<?php echo $userId;?>" class="sidebar-nav-item">
            <svg class="sidebar-nav-item-icon">
                <use xlink:href="#navUser"></use>
            </svg>
            <p>мой профиль</p>
        </a>
        <a href="/admin/take/" class="sidebar-nav-item">
            <svg class="sidebar-nav-item-icon">
                <use xlink:href="#navMoney"></use>
            </svg>
            <p>выплаты</p>
        </a>
		<a href="/admin/takes/" class="sidebar-nav-item">
            <svg class="sidebar-nav-item-icon">
                <use xlink:href="#navMoney"></use>
            </svg>
            <p>История выплаты</p>
        </a>
		<a href="/admin/queries/" class="sidebar-nav-item">
            <svg class="sidebar-nav-item-icon">
                <use xlink:href="#navMoney"></use>
            </svg>
            <p>Новый пользователь</p>
        </a>
        <a href="/admin/team/page-1" class="sidebar-nav-item">
            <svg class="sidebar-nav-item-icon">
                <use xlink:href="#presentationYouth"></use>
            </svg>
            <p>таблица участников</p>
        </a>
		<a href="/admin/teams/<?php echo $user['id'];?>" class="sidebar-nav-item">
            <svg class="sidebar-nav-item-icon">
                <use xlink:href="#navUsers"></use>
            </svg>
            <p>таблица подразделений</p>
        </a>
        <a href="/admin/academy" class="sidebar-nav-item">
            <svg class="sidebar-nav-item-icon">
                <use xlink:href="#navBook"></use>
            </svg>
            <p>академия лидеров</p>
        </a>
        
        <a href="/admin/news" class="sidebar-nav-item" id="news">
            <svg class="sidebar-nav-item-icon">
                <use xlink:href="#navRadio"></use>
            </svg>
            <p>новости компании</p>
        </a>
    </nav>
</div>