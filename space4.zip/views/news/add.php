<?php include ROOT.'/views/layouts/header.php';?>
<?php include ROOT.'/views/layouts/svg.php';?>
<section class="control-panel-main">
<?php include ROOT.'/views/layouts/sidebar.php';?>
    <div class="control-panel-content">
        <div class="kabinet-news-main-box">
            <div class="my-profile-content-top">
                <p>Новости ТОО Space Line</p>
				
                <a href="/cabinet/logout">
                    <svg class="control-panel-logout">
                        <use xlink:href="#LogoutIcon"></use>
                    </svg>
                </a>
            </div>
            <div class="kabiet-news-items">

                      
            </div>
        </div>

    </div>
</section>

</body>
</html>
