<?php include ROOT.'/views/layouts/header.php';?>

<body>
<?php include ROOT.'/views/layouts/svg.php';?>
<section class="control-panel-main">
    <div class="left-sidebar">
        <?php require '/includes/logo-bar.php';?>
        <?php require '/includes/user-bar.php';?>
        <?php require '/includes/nav-bar.php';?>
    </div>
    <div class="control-panel-content">
        <div class="kabinet-news-main-box">
            <div class="my-profile-content-top">
                <p>Новости ТОО Space Line</p>

					<a href="add_news.php" class="btn btn-success">Добавить новость</a>

                <a href="logout.php">
                    <svg class="control-panel-logout">
                        <use xlink:href="#LogoutIcon"></use>
                    </svg>
                </a>
            </div>
            <div class="kabiet-news-items">


                        <div class="kabinet-news-item">
                            <img src="images_posts/<?php echo $post_image;?>">
                            <h3><?php echo $post_name;?></h3>
                            <div class="news-date-btn">
                                <p class="article-date">Дата: <?php echo $post_data_publish;?></p>
                                <a href="news-view.php?id=<?php echo $post_id;?>" class="news-more">Подробнее</a>
                            </div>
                        </div>


<!--                <div class="kabinet-news-item">-->
<!--                    <img src="img/kabinet-news-page/news-picture.jpg">-->
<!--                    <h3>Заголовок новости</h3>-->
<!--                    <div class="news-date-btn">-->
<!--                        <p class="article-date">Дата: 24.09.2019</p>-->
<!--                        <a href="#" class="news-more">Подробнее</a>-->
<!--                    </div>-->
<!--                </div>-->
<!--                <div class="kabinet-news-item">-->
<!--                    <img src="img/kabinet-news-page/news-picture.jpg">-->
<!--                    <h3>Заголовок новости</h3>-->
<!--                    <div class="news-date-btn">-->
<!--                        <p class="article-date">Дата: 24.09.2019</p>-->
<!--                        <a href="#" class="news-more">Подробнее</a>-->
<!--                    </div>-->
<!--                </div>-->
<!--                <div class="kabinet-news-item">-->
<!--                    <img src="img/kabinet-news-page/news-picture.jpg">-->
<!--                    <h3>Заголовок новости</h3>-->
<!--                    <div class="news-date-btn">-->
<!--                        <p class="article-date">Дата: 24.09.2019</p>-->
<!--                        <a href="#" class="news-more">Подробнее</a>-->
<!--                    </div>-->
<!--                </div>-->
            </div>
        </div>

    </div>
</section>
<?php require 'template-parts/scripts.php';?>
</body>
</html>
