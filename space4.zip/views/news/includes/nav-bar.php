<nav class="sidebar-nav">
    <a href="control-panel.php?id=<?php echo $id;?>" class="sidebar-nav-item nav-item-active">
        <svg class="sidebar-nav-item-icon">
            <use xlink:href="#navUser"></use>
        </svg>
        <p>Панель управления</p>
    </a>
    <a href="profile.php?id=<?php echo $id;?>" class="sidebar-nav-item">
        <svg class="sidebar-nav-item-icon">
            <use xlink:href="#navUser"></use>
        </svg>
        <p>Мой профиль</p>
    </a>
	<a href="table.php" class="sidebar-nav-item">
        <svg class="sidebar-nav-item-icon">
            <use xlink:href="#navBook"></use>
        </svg>
        <p>Таблица доходов</p>
    </a>
    <a href="news.php" class="sidebar-nav-item">
        <svg class="sidebar-nav-item-icon">
            <use xlink:href="#navRadio"></use>
        </svg>
        <p>Новости</p>
    </a>
	<a href="academy-leaders.php" class="sidebar-nav-item">
        <svg class="sidebar-nav-item-icon">
            <use xlink:href="#navBook"></use>
        </svg>
        <p>Академия лидеров</p>
    </a>
	<a href="team.php?id=<?php echo $id;?>" class="sidebar-nav-item">
        <svg class="sidebar-nav-item-icon">
            <use xlink:href="#navUsers"></use>
        </svg>
        <p>Моя команда</p>
    </a>

</nav>