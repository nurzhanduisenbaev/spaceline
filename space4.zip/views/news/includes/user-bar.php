<div class="left-sidebar-user">
    <div class="left-sidebar-user-photo">
      <?php
if ($image == "none.jpg") {
  echo "        <img src='includes/img_icons/none.jpg'>";
}else {
    echo "        <img src='includes/img_icons/$image'>";
}
       ?>
    </div>
    <div class="left-sidebar-user-name">
        <div style="padding-left:20px;border-bottom:1px solid white;height:60px;">
			<a href="profile.php?id=<?php echo $id;?>"><?php echo $name . ' '.$surname.'.';?>
			</a>
			<p><?php if($role=='Лидер'){
						echo ucfirst($role);
					}else{
						echo '';
						}
				?></p><br>
		</div>
		<p style="padding: 10px 0 0 0;"><?php echo 'Статус: <b>'.$status.'</b>';?></p>
    </div>
</div>
