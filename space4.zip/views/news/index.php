<?php include ROOT.'/views/layouts/header.php';?>
<?php include ROOT.'/views/layouts/svg.php';?>
<section class="control-panel-main">
<?php include ROOT.'/views/layouts/sidebar.php';?>
    <div class="control-panel-content">
        <div class="kabinet-news-main-box">
            <div class="my-profile-content-top">
                <p>Новости ТОО Space Line</p>
				<?php if($user['role'] == 'Лидер'):?>
					<a href="/news/add" class="btn btn-success">Добавить новость</a>
				<?php endif;?>
                <a href="/cabinet/logout">
                    <svg class="control-panel-logout">
                        <use xlink:href="#LogoutIcon"></use>
                    </svg>
                </a>
            </div>
            <div class="kabiet-news-items">

                        <div class="kabinet-news-item">
                            <img src="images_posts/post_image">
                            <h3>post_name</h3>
                            <div class="news-date-btn">
                                <p class="article-date">Дата: post_data_publish</p>
                                <a href="news-view.php?id=post_id" class="news-more">Подробнее</a>
                            </div>
                        </div>


<!--                <div class="kabinet-news-item">-->
<!--                    <img src="img/kabinet-news-page/news-picture.jpg">-->
<!--                    <h3>Заголовок новости</h3>-->
<!--                    <div class="news-date-btn">-->
<!--                        <p class="article-date">Дата: 24.09.2019</p>-->
<!--                        <a href="#" class="news-more">Подробнее</a>-->
<!--                    </div>-->
<!--                </div>-->
<!--                <div class="kabinet-news-item">-->
<!--                    <img src="img/kabinet-news-page/news-picture.jpg">-->
<!--                    <h3>Заголовок новости</h3>-->
<!--                    <div class="news-date-btn">-->
<!--                        <p class="article-date">Дата: 24.09.2019</p>-->
<!--                        <a href="#" class="news-more">Подробнее</a>-->
<!--                    </div>-->
<!--                </div>-->
<!--                <div class="kabinet-news-item">-->
<!--                    <img src="img/kabinet-news-page/news-picture.jpg">-->
<!--                    <h3>Заголовок новости</h3>-->
<!--                    <div class="news-date-btn">-->
<!--                        <p class="article-date">Дата: 24.09.2019</p>-->
<!--                        <a href="#" class="news-more">Подробнее</a>-->
<!--                    </div>-->
<!--                </div>-->
            </div>
        </div>

    </div>
</section>

</body>
</html>
