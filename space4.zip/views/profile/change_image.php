<?php include ROOT.'/views/layouts/header.php';?>
<?php include ROOT.'/views/layouts/svg.php';?>
<section class="my-profile-main">
    <?php include ROOT.'/views/layouts/sidebar.php';?>
    <div class="my-profile-main-box">
        <div class="my-profile-content-top">
            <p>Мой профиль</p>
            <a href="logout.php">
                <svg class="control-panel-logout">
                    <use xlink:href="#LogoutIcon"></use>
                </svg>
            </a>
        </div>
		
        <div class="my-profile-main-info">
            <div class="my-profile-main-info-left">
                <div class="my-profile-main-info-left-top">
                    <div class="my-profile-main-info-left-top-first">
                        <div class="my-profile-main-info-photo">
                            <img src="/template/img/my-profile/<?php echo $user['image'];?>">
                        </div>
                        <div class="my-profile-main-info-name">
                            <h4><?php echo $user['name'].' '.$user['surname'].' '.$user['lastname'];?></h4>
                            <p><?php echo $user['role'];?></p>
                        </div>
                    </div>

                </div>
                <div class="my-profile-main-info-left-bottom">
                    <p>Форматы (gif,png,jpg,jpeg)</p>
                    <div class="my-profile-main-info-left-bottom-linkblock">
                      <form  enctype="multipart/form-data" method="post">

                        <input id="pic" name="picture" type="file" /><br><br>
                        <input class="input_btn" name = "add_image" type="submit" value="Загрузить" />
                      </form>
                    </div>


                </div>
            </div> <!-- /.my-profile-main-info-left -->

        </div> <!-- /.my-profile-main-info -->
    </div> <!-- /.my-profile-main-box -->
</section>
<style>
.my-profile-main-info-left-top {
  height: 55%;
  width: 100%;
  background: #EBF9FF;
  padding: 15px 0;
}
.input_btn{
  width: 100%;
    height: 41px;
    border: 1px solid #9deae9;
    border-radius: 5px;
    margin-left: 20%;
}
#pic{
  margin-left: 20%;
}
</style>
</body>
</html>
