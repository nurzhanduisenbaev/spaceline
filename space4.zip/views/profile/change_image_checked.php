<?php
$servername = "srv-db-plesk02.ps.kz"; // локалхост
$username = "htbkz_root"; // имя пользователя
$password = "Web123!@#"; // пароль если существует
$dbname = "htbkz12_space"; // база данных

$conn = new mysqli($servername, $username, $password, $dbname);
// Проверка соединения
if ($conn->connect_error) {
   die("Ошибка подключения: " . $conn->connect_error);
}

$numbers = rand(0,9999);
$chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
$name_files = $numbers . substr(str_shuffle($chars), 0, 10) . $numbers;

$path = 'img_icons/';
$tmp_path = 'tmp/';
// Массив допустимых значений типа файла
$types = array('image/gif', 'image/png', 'image/jpeg', 'image/jpg');
// Максимальный размер файла
$size = 2000000;


if ($_POST['add_image']){
  if (!in_array($_FILES['picture']['type'], $types))
    die('Запрещённый тип файла. <a href="?">Попробовать другой файл?</a>');

 // Проверяем размер файла
 if ($_FILES['picture']['size'] > $size)
    die('Слишком большой размер файла. <a href="change_image.php">Попробовать другой файл?</a>');
 if (!@copy($_FILES['picture']['tmp_name'], $path . $_FILES['picture']['name']))
 echo 'Что-то пошло не так';
 else

 if ($_FILES['picture']['type'] == 'image/png') {
   $conn->query("UPDATE `users` SET `image` = '$name_files.png' WHERE `users`.`email` = '$_COOKIE[username]'");
   rename("img_icons/" . $_FILES['picture']['name'] , "img_icons/" . $name_files  . ".png");
   echo '<a>Аватарка обновленна!</a><br>';
   echo '<a href="profile.php">Перейти на главную</a>';
 }elseif ($_FILES['picture']['type'] == 'image/gif') {
   $conn->query("UPDATE `users` SET `image` = '$name_files.gif' WHERE `users`.`email` = '$_COOKIE[username]'");
   rename("img_icons/" . $_FILES['picture']['name'] , "img_icons/" . $name_files  . ".gif");
   echo '<a>Аватарка обновленна!</a><br>';
   echo '<a href="profile.php">Перейти на главную</a>';
 }elseif ($_FILES['picture']['type'] == 'image/jpeg') {
   $conn->query("UPDATE `users` SET `image` = '$name_files.jpeg' WHERE `users`.`email` = '$_COOKIE[username]'");
   rename("img_icons/" . $_FILES['picture']['name'] , "img_icons/" . $name_files  . ".jpeg");
   echo '<a>Аватарка обновленна!</a><br>';
   echo '<a href="profile.php">Перейти на главную</a>';
 }elseif ($_FILES['picture']['type'] == 'image/jpg') {
   $conn->query("UPDATE `users` SET `image` = '$name_files.jpg' WHERE `users`.`email` = '$_COOKIE[username]'");
   rename("img_icons/" . $_FILES['picture']['name'] , "img_icons/" . $name_files  . ".jpg");
   echo '<a>Аватарка обновленна!</a><br>';
   echo '<a href="profile.php">Перейти на главную</a>';
 }
}
 ?>
