<?php include ROOT.'/views/layouts/header.php';?>
<?php include ROOT.'/views/layouts/svg.php';?>
<section class="control-panel-main">
    
        <?php include ROOT.'/views/layouts/sidebar.php';?>
        <div class="control-panel-content">
            <div class="control-panel-content-top">
                <p>Редактирование</p>
                <a href="/cabinet/logout">
                    <svg class="control-panel-logout">
                        <use xlink:href="#LogoutIcon"></use>
                    </svg>
                </a>
            </div> <!-- /.control-panel-content-top -->
            <div class="control-panel-money-statistics">
                
                <div id="registerForm">
                    <form method="post" enctype="multipart/form-data">
                        <fieldset>
                            <legend>Учетная запись</legend>
                            <div class="data-group">
                                <label>Роль</label>
                                <input type="text" name="role" class="role" value="<?php echo $user['mstatus'];?>" readonly>
                            </div>
                            <div class="data-group">
                                <label for="email">Email<span style="color:red;">*</span></label>
                                <input type="text" name="email" class="email" id="email" value="<?php echo $user['email'];?>" required>
                            </div>
                            <div class="data-group">
                                <label for="password">Пароль<span style="color:red;">*</span></label>
                                <input type="text" name="password" class="password" id="password" value="<?php echo $user['password'];?>" required>
                            </div>
                            <div class="data-group">
                                <label for="surname">Фамилия<span style="color:red;">*</span></label>
                                <input type="text" name="surname" class="surname" id="surname" readonly value="<?php echo $user['surname'];?>">
                            </div>
                            <div class="data-group">
                                <label for="name">Имя<span style="color:red;">*</span></label>
                                <input type="text" name="name" class="name" id="name" readonly value="<?php echo $user['name'];?>">
                            </div>
                            <div class="data-group">
                                <label for="lastname">Отчество<span style="color:red;">*</span></label>
                                <input type="text" name="lastname" class="lastname" id="lastname" readonly value="<?php echo $user['lastname'];?>">
                            </div>
                            <div class="data-group">
                                <label for="data_born">Дата рождения<span style="color:red;">*</span></label>
                                <div id="datatimepicker1">
                                    <input type="text" name="data_born" class="data_born" id="data_born" readonly value="<?php echo $user['data_born'];?>">
                                </div>
                            </div>
                            <div class="data-group">
                                <label>Пол<span style="color:red;">*</span></label>
                                <div id="sexy">
                                    <div class="sexy-item">
                                        <label for="male">Мужчина</label>
                                        <input type="radio" name="sex" class="sex" value="Мужщина" id="male">
                                    </div>
                                    <div class="sexy-item">
                                        <label for="female">Женщина</label>
                                        <input type="radio" name="sex" class="sex" value="Женщина" id="female">
                                    </div>
                                </div>
                            </div>
                            <div class="data-group">
                                <label for="iin">ИИН<span style="color:red;">*</span></label>
                                <input type="text" name="iin" class="iin" id="iin" readonly value="<?php echo $user['iin'];?>">
                            </div>
                            <div class="data-group">
                                <label for="card">Номер карты<span style="color:red;">*</span></label>
                                <input type="text" name="card" class="card" id="card" value="<?php echo $user['card'];?>">
                            </div>
                            <div class="data-group">
                                <label for="invoice">Номер счета<span style="color:red;">*</span></label>
                                <input type="text" name="invoice" class="invoice" id="invoice" value="<?php echo $user['invoice'];?>">
                            </div>
                            <div class="data-group">
                                <label for="data_reg">Дата регистраций<span style="color:red;">*</span></label>
                                <input type="text" name="data_reg" class="data_reg" id="data_reg" readonly value="<?php echo $user['data_reg'];?>" required>
                            </div>
                        </fieldset>
                        <fieldset>
                            <legend>Адрес</legend>
                            <div class="data-group">
                                <label for="country">Страна<span style="color:red;">*</span></label>
                                <input type="text" name="country" class="country" id="country" required value="<?php echo $user['country'];?>">
                            </div>
                            <div class="data-group">
                                <label for="city">Город<span style="color:red;">*</span></label>
                                <input type="text" name="city" class="city" id="city" required value="<?php echo $user['city'];?>">
                            </div>
                            <div class="data-group">
                                <label for="street">Улица<span style="color:red;">*</span></label>
                                <input type="text" name="street" class="street" id="street" required value="<?php echo $user['street'];?>">
                            </div>
                            <div class="data-group">
                                <label for="house">Дом<span style="color:red;">*</span></label>
                                <input type="text" name="house" class="house" id="house" required value="<?php echo $user['house'];?>">
                            </div>
                            <div class="data-group">
                                <label for="room">Квартира</label>
                                <input type="text" name="room" class="room" id="room" value="<?php echo $user['room'];?>">
                            </div>
                        </fieldset>
                        <fieldset>
                            <legend>Регистрационные сведения</legend>
                            <div class="data-group">
                                <label for="who">Закреплен за<span style="color:red;">*</span></label>
								<?php $par = User::getUserById($user['parent_id']);?>
								<input type="text" value="<?php echo $par['email'];?>" readonly>
                            </div>
                           
                            <div class="data-group">
                                <label for="product">Бизнес продукт<span style="color:red;">*</span></label>
                                <input type="text" value="<?php echo $user['product'];?>" readonly>
                            </div>
                            <div class="data-group">
                                <label for="team">Подразделение</label>
                                <input type="text" name="team" class="team" id="team" readonly value="<?php echo $user['team'];?>">
                            </div>
                            
                        </fieldset>
                        
                        <fieldset>
                            <div class="data-group">
                                <input type="submit" name="update" class="update" value="Обновить">
                            </div>
                        </fieldset>
                        
                    </form>
                </div>
                
            </div> <!-- /.control-panel-money-statistics -->
            
        </div>
    </section>
<?php include ROOT.'/views/layouts/footer.php';?>
