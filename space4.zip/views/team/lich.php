<?php include ROOT.'/views/layouts/header.php';?>
<?php include ROOT.'/views/layouts/svg.php';?>
<section class="control-panel-main">

    <?php include ROOT.'/views/layouts/sidebar.php';?>
    <div class="control-panel-content">
        <div class="control-panel-content-top">
            <p>панель управления</p>
            <a href="/user/register" class="top_button">
                Добавить партнера
            </a>
            <a href="/cabinet/logout">
                <svg class="control-panel-logout">
                    <use xlink:href="#LogoutIcon"></use>
                </svg>
            </a>
        </div> <!-- /.control-panel-content-top -->
        <div class="control-panel-money-statistics">
			<table class="table table-stripped table-bordered">
				<thead>
					<tr>
						<th>#</th>
						<th>Ф.И.О</th>
						<th>Email</th>
						<th>Пакет</th>
						
					</tr>
				</thead>
				<tbody>
					<?php $index=0;?>
					<?php foreach($mass as $item):?>
					
					<?php $index++;?>
					<tr>
						<td><?php echo $index;?></td>
						<td><?php echo $item['fio'];?></td>
						<td><?php echo $item['email'];?></td>
						<td><?php echo $item['packet'];?></td>
					</tr>
					<?php endforeach;?>
				</tbody>
			</table>
        </div> <!-- /.control-panel-money-statistics -->

    </div>
</section>
<style>
	div.node{
		width: 120px;
	}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<?php include ROOT.'/views/layouts/footer.php';?>
