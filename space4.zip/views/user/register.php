<?php include ROOT.'/views/layouts/header.php';?>
<?php include ROOT.'/views/layouts/svg.php';?>
<section class="control-panel-main">
        <?php include ROOT.'/views/layouts/sidebar.php';?>
        <div class="control-panel-content">
            <div class="control-panel-content-top">
                <p>Регистрация Партнеров</p>
                <a href="/cabinet/logout">
                    <svg class="control-panel-logout">
                        <use xlink:href="#LogoutIcon"></use>
                    </svg>
                </a>
            </div> <!-- /.control-panel-content-top -->
            <div class="control-panel-money-statistics">
                <?php
                    if(isset($errors) && is_array($errors)){
                        foreach ($errors as $error){
                            echo '<span style="color:red;">';
                            print_r ($error);
                            echo '</span>';
                        }
                    }
                ?>
				<div id='uvedomlenie' style="display:none;">
					Вы успешно подали анкету на регистрацию нового пользователя в  партнерской системе Spaceline<br>
					Ответ от администрации сайта пользователь получит на электронный адрес 
				</div>
                <div id="registerForm">
                    <form method="post" enctype="multipart/form-data">
                        <fieldset>
                            <legend>Учетная запись</legend>
                            <div class="data-group">
                                <label for="role">Роль</label>
                                <?php if($user['role'] == 'Лидер'):?>
									<select id="role" class="role" name="role">
										<option value="Партнер">Партнер</option>
										<option value="Лидер">Лидер</option>
									</select>
								<?php else:?>
									<input type="text" id="role" name="role" class="role" value="Партнер" readonly>
								<?php endif;?>
                            </div>
                            <div class="data-group">
                                <label for="email">Email<span style="color:red;">*</span></label>
                                <input type="text" name="email" class="email" id="email" required>
                            </div>
                            <div class="data-group">
                                <label for="password">Пароль<span style="color:red;">*</span></label>
                                <input type="text" name="password" class="password" id="password" required>
                            </div>
                            <div class="data-group">
                                <label for="surname">Фамилия<span style="color:red;">*</span></label>
                                <input type="text" name="surname" class="surname" id="surname" required>
                            </div>
                            <div class="data-group">
                                <label for="name">Имя<span style="color:red;">*</span></label>
                                <input type="text" name="name" class="name" id="name" required>
                            </div>
                            <div class="data-group">
                                <label for="lastname">Отчество<span style="color:red;">*</span></label>
                                <input type="text" name="lastname" class="lastname" id="lastname">
                            </div>
                            <div class="data-group">
                                <label for="data_born">Дата рождения<span style="color:red;">*</span></label>
                                <div id="datatimepicker1">
                                    <input type="text" name="data_born" class="data_born" id="data_born" required>
                                </div>
                            </div>
                            <div class="data-group">
                                <label>Пол<span style="color:red;">*</span></label>
                                <div id="sexy">

                                    <div class="sexy-item">
                                        <label for="male">Мужчина</label>
                                        <input type="radio" name="sex" class="sex" value="Мужщина" id="male">
                                    </div>
                                    <div class="sexy-item">
                                        <label for="female">Женщина</label>
                                        <input type="radio" name="sex" class="sex" value="Женщина" id="female">
                                    </div>
                                </div>
                            </div>
                            <div class="data-group">
                                <label for="iin">ИИН<span style="color:red;">*</span></label>
                                <input type="text" name="iin" class="iin" id="iin" required>
                            </div>
                            <div class="data-group">
                                <label for="card">Номер карты<span style="color:red;">*</span></label>
                                <input type="text" name="card" class="card" id="card" required>
                            </div>
                            <div class="data-group">
                                <label for="invoice">Номер счета<span style="color:red;">*</span></label>
                                <input type="text" name="invoice" class="invoice" id="invoice" required>
                            </div>
                            <div class="data-group">
                                <label for="data_reg">Дата регистраций<span style="color:red;">*</span></label>
                                <input type="text" name="data_reg" class="data_reg" id="data_reg" readonly value="<?php echo date('Y-m-d');?>" required>
                            </div>
                        </fieldset>
                        <fieldset>
                            <legend>Адрес</legend>
                            <div class="data-group">
                                <label for="country">Страна<span style="color:red;">*</span></label>
                                <input type="text" name="country" class="country" id="country" required>
                            </div>
                            <div class="data-group">
                                <label for="city">Город<span style="color:red;">*</span></label>
                                <input type="text" name="city" class="city" id="city" required>
                            </div>
                            <div class="data-group">
                                <label for="street">Улица<span style="color:red;">*</span></label>
                                <input type="text" name="street" class="street" id="street" required>
                            </div>
                            <div class="data-group">
                                <label for="house">Дом<span style="color:red;">*</span></label>
                                <input type="text" name="house" class="house" id="house" required>
                            </div>
                            <div class="data-group">
                                <label for="room">Квартира</label>
                                <input type="text" name="room" class="room" id="room">
                            </div>
                        </fieldset>
                        <fieldset>
                            <legend>Регистрационные сведения</legend>
                            <div class="data-group">
                                <label for="who">Закреплен за<span style="color:red;">*</span></label>

                                <select id="who" class="who" name="who">
                                    <?php foreach ($newMass as $item):?>
                                    <?php
                                        if($item['mleft'] == ''){
                                            $left = 'Пустой';
                                        }else{
                                            $left = 'Занят';
                                        }
                                        if($item['mright'] == ''){
                                            $right = 'Пустой';
                                        }else{
                                            $right = 'Занят';
                                        }
                                    ?>
                                        <option value="<?php echo $item['id']?>">
                                            <?php echo $item['fio'];?>
                                            Левая: <?php echo $left;?> |
                                            Правая: <?php echo $right;?>
                                        </option>
                                    <?php endforeach;?>
                                </select>
                            </div>
                            <div class="data-group">
                                <label for="side">Сторона<span style="color:red;">*</span></label>
                                <select id="side" class="side" name="side">
                                    <option value="mleft">Левая</option>
                                    <option value="mright">Правая</option>
                                </select>
                            </div>
                            <div class="data-group">
                                <label for="product">Бизнес продукт<span style="color:red;">*</span></label>
                                <select id="product" class="product" name="product">
                                    <?php while ($pr = $getProduct->fetch(PDO::FETCH_ASSOC)):?>
                                    <option value="<?php echo $pr['product_name'];?>">
                                        <?php echo $pr['product_name'];?>
                                    </option>
                                    <?php endwhile;?>
                                </select>
                            </div>
                            <div class="data-group">
                                <label for="team2">Подразделение</label>
									<input type="text" name="team" class="team" id="team2" readonly value="<?php echo $user['team'];?>">		
                            </div>
                            <div class="data-group">
                                <label for="oplata">Квитанция оплаты<span style="color:red;">*</span></label>
                                <input type="file" id="oplata" class="oplata" name="oplata">
                            </div>
                        </fieldset>

                        <fieldset>
                            <div class="data-group">
                                <input type="submit" name="register" class="register" value="Добавить"  />
                            </div>
                        </fieldset>

                    </form>
                </div>

            </div> <!-- /.control-panel-money-statistics -->

        </div>
    </section>
<?php include ROOT.'/views/layouts/footer.php';?>
<script>
	//$('#team').val();
	var team = "<?php echo $user['team'];?>";
	//$('#team').attr('readonly','readonly').val(team);
$('#role').change(function(){
	console.log($(this).val());
	var val = $(this).val();
	if(val == 'Лидер'){
		$('#team2').removeAttr('readonly').val('');
	}else{
		$('#team2').attr('readonly','readonly').val(team);
	}
});
</script>
<?php if($ok):?>
<script>
$('#uvedomlenie').css({
	'border': '1px solid black',
	'position': 'fixed',
	'top': '5px',
	'padding': '10px',
	'display': 'block',
	'background':'#393186',
	'color':'#fff',
	'transition':'all 0.6',
});
	$('#uvedomlenie').click(function(){
		$(this).hide();
	});
</script>
<?php endif;?>
